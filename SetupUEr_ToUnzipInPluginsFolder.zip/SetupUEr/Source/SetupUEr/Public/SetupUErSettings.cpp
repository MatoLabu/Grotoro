// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErPrivatePCH.h"
#include "SetupUErSettings.h"
/// IMPORTANT
/// *If* you want to use the C++ code to adjust the SetupUEr settings during gameplay instead of the supplied BP library,
/// make sure you copy/paste this whole code section to one of your game's cpp files, surrounded by 
/// #if WITH_EDITOR
/// #endif
/// compiler directives, since the developement_editor build does *not* see these plugin ones.
/// If you *don't* use the compiler directives however, you will get duplicate declaration errors at package time.
/// Also, make sure you add the following line to your project's build.cs file:
/// PublicDependencyModuleNames.AddRange(new string[] { "SetupUEr" }); 

bool SetupUErSettings::isActive;
FString SetupUErSettings::title;
FString SetupUErSettings::commandLine;
FString SetupUErSettings::gameName;
FName SetupUErSettings::logoName;
TArray<FString> SetupUErSettings::activePlugins;
int SetupUErSettings::minResY;

int SetupUErSettings::AAQuality;
int SetupUErSettings::EffectsQuality;
int SetupUErSettings::FoliageQuality;
int SetupUErSettings::PostProcessQuality;
int SetupUErSettings::ResolutionQuality;
int SetupUErSettings::ShadowQuality;
int SetupUErSettings::TextureQuality;
int SetupUErSettings::ViewDistanceQuality;

int SetupUErSettings::resolutionX;
int SetupUErSettings::resolutionY;
int SetupUErSettings::fullScreenMode;
int SetupUErSettings::monitor;

int SetupUErSettings::vSync;

bool SetupUErSettings::pluginOverride;

bool SetupUErSettings::allowWonkyKeys;

TArray<FInputAxisKeyMapping> SetupUErSettings::originalAxisMappings;
TArray<FInputActionKeyMapping> SetupUErSettings::originalActionMappings;

TArray<TSharedPtr<FInputAxisKeyMapping>> SetupUErSettings::modifiedAxisMappings;
TArray<TSharedPtr<FInputActionKeyMapping>> SetupUErSettings::modifiedActionMappings;

TArray<FString> SetupUErSettings::backupAxisMappings;
TArray<FString> SetupUErSettings::backupActionMappings;
// SetupUEr - Runtime version of the settings
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once
//#include "SetupUErPrivatePCH.h"
#include "Engine.h"
#include "UnrealClient.h"

// plugin types
static const FString cGraphics = "Graphics";
static const FString cQuality = "Quality";
static const FString cKeyboard = "Keyboard";


struct FMatchMappingByName
{
	FMatchMappingByName(const FName InName)
		: Name(InName)
	{
	}

	bool operator() (const FInputActionKeyMapping& ActionMapping)
	{
		return ActionMapping.ActionName == Name;
	}

	bool operator() (const FInputAxisKeyMapping& AxisMapping)
	{
		return AxisMapping.AxisName == Name;
	}

	FName Name;
};


class SetupUErSettings
{
public: 

	static FString title;
	static FString commandLine;
	static FName logoName;
	static bool isActive; 
	static TArray<FString> activePlugins;
	static FString gameName;

	static int minResY;

	static int AAQuality;
	static int EffectsQuality;
	static int FoliageQuality;
	static int PostProcessQuality;
	static int ResolutionQuality;
	static int ShadowQuality;
	static int TextureQuality;
	static int ViewDistanceQuality;

	static int fullScreenMode;
	static int resolutionX;
	static int resolutionY;
	static int monitor;

	static int vSync;

	static bool pluginOverride;
	static bool allowWonkyKeys;

	static TArray<FInputAxisKeyMapping> originalAxisMappings;
	static TArray<FInputActionKeyMapping> originalActionMappings;

	static TArray<TSharedPtr<FInputAxisKeyMapping>> modifiedAxisMappings;
	static TArray<TSharedPtr<FInputActionKeyMapping>> modifiedActionMappings;

	// these are here for the in-game version
	static TArray<FString> backupAxisMappings;
	static TArray<FString> backupActionMappings;

	static bool IsKeyboardKey(FKey inKey)
	{ // let's keep mouse buttons too
		return (!((inKey.IsGamepadKey()) ||
			(inKey == EKeys::MouseX) ||
			(inKey == EKeys::MouseY) ||
			(inKey == EKeys::MouseScrollUp) ||
			(inKey == EKeys::MouseScrollDown) ||
			(inKey == EKeys::MouseWheelAxis)))
			;
	}

	static void GenerateDefaultSettings()
	{
		UE_LOG(LogTemp, Error, TEXT("SetupUEr: No settings found. Make sure you've set up your SetupUEr data in-editor!"));
		isActive = false;
		minResY = 720;
		title = "U N T I T L E D";
		activePlugins.Add(cGraphics);
		allowWonkyKeys = false;
	}

	static void LoadConfig(bool firstLoad = false)
	{
		bool persistentSettings = false;
		// there's probably an in-engine var for this, but given that I see a lot of UE4 games still called "shootergame", I prefer to make sure and base it on the directory
		// Also, you know, the whole "no GEngine yet" thing
		gameName = FPaths::GameDir();
		gameName.RemoveFromEnd("/");
		gameName = gameName.RightChop(gameName.Find("/", ESearchCase::IgnoreCase, ESearchDir::FromEnd)+1);

		// Default UI scale
		minResY = 720;

		// Default scalability to max
		SetupUErSettings::AAQuality = 3;
		SetupUErSettings::EffectsQuality = 3;
		SetupUErSettings::FoliageQuality = 3;
		SetupUErSettings::PostProcessQuality = 3;
		SetupUErSettings::ResolutionQuality = 100;
		SetupUErSettings::ShadowQuality = 3;
		SetupUErSettings::TextureQuality = 3;
		SetupUErSettings::ViewDistanceQuality = 3;

		// Default resolution stuff
		SetupUErSettings::resolutionX = 1280;
		SetupUErSettings::resolutionY = 720;
		SetupUErSettings::fullScreenMode = 0;

		// Default keyboard settings
		if (firstLoad)
		{
			UInputSettings* UIS = GetMutableDefault<UInputSettings>();
			TArray<FName> actionNames, axisNames;
			UIS->GetActionNames(actionNames);
			UIS->GetAxisNames(axisNames);

			SetupUErSettings::originalActionMappings.Empty();
			for (int i = 0; i < actionNames.Num(); i++)
			{
				SetupUErSettings::originalActionMappings.Append(UIS->ActionMappings.FilterByPredicate(FMatchMappingByName(actionNames[i])));
				for (int j = SetupUErSettings::originalActionMappings.Num() - 1; j >= 0; j--)
				{
					if (!SetupUErSettings::IsKeyboardKey(SetupUErSettings::originalActionMappings[j].Key)) // we're not touching controller stuff
						SetupUErSettings::originalActionMappings.RemoveAt(j);
				}
			}

			SetupUErSettings::originalAxisMappings.Empty();
			for (int i = 0; i < axisNames.Num(); i++)
			{
				SetupUErSettings::originalAxisMappings.Append(UIS->AxisMappings.FilterByPredicate(FMatchMappingByName(axisNames[i])));
				for (int j = SetupUErSettings::originalAxisMappings.Num() - 1; j >= 0; j--)
				{
					if (!SetupUErSettings::IsKeyboardKey(SetupUErSettings::originalAxisMappings[j].Key))
						SetupUErSettings::originalAxisMappings.RemoveAt(j);
				}
			}

			SetupUErSettings::modifiedAxisMappings.Empty();
			for (int i = 0; i < SetupUErSettings::originalAxisMappings.Num(); i++)
				SetupUErSettings::modifiedAxisMappings.Add(MakeShareable(new FInputAxisKeyMapping(SetupUErSettings::originalAxisMappings[i])));

			SetupUErSettings::modifiedActionMappings.Empty();
			for (int i = 0; i < SetupUErSettings::originalActionMappings.Num(); i++)
				SetupUErSettings::modifiedActionMappings.Add(MakeShareable(new FInputActionKeyMapping(SetupUErSettings::originalActionMappings[i])));
		}

		pluginOverride = false;



		// check if we have a game-specific config file?
		FString configName = FPaths::GameDir() + gameName + ".cfg";
		TArray<FString> configLines;
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
		{
			persistentSettings = true;
		}

		// read the main settings
		configName = FPaths::GameConfigDir() + "SetupUEr.cfg";
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
		{
			configLines.Empty();
			FString UTF16test;
			FFileHelper::LoadFileToString(UTF16test, *configName);
			UTF16test = UTF16test.Replace(TEXT("\r"), TEXT(""));
			UTF16test.ParseIntoArray(configLines, TEXT("\n"), false);
			UTF16test.Empty();
			if (configLines.Num() == 7)
			{
				UE_LOG(LogTemp, Log, TEXT("SetupUEr: Reading basic config file."));
				title = configLines[1];
				logoName = FName(*configLines[2]);
//				if (!persistentSettings)  // these will get overwritten later anyway?
				{
					UE_LOG(LogTemp, Log, TEXT("SetupUEr: No persistent settings found. First run?"));
					isActive = (FCString::Atoi(*configLines[0]) == 1) ? true : false;
					commandLine = configLines[3];
					minResY = (FCString::Atoi(*configLines[5]));
					allowWonkyKeys = (FCString::Atoi(*configLines[6]) == 1) ? true : false;
				}

				configLines[4].ParseIntoArray(activePlugins, TEXT(","));
				minResY = (FCString::Atoi(*configLines[5]));
				allowWonkyKeys = (FCString::Atoi(*configLines[6]) == 1) ? true : false;

				if (activePlugins.Num() == 0)
					activePlugins.Add(cGraphics);
			}
			else
				GenerateDefaultSettings();
		}

		// test for our own settings, since UE's ini config handling stuff is arcane and can't actually be accessed this early in the process apparently... so we'll just duplicate everything
		configName = FPaths::GameDir() + gameName+ ".cfg";
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
		{
			configLines.Empty();
			FFileHelper::LoadANSITextFileToStrings(*(configName), NULL, configLines);
			if (configLines.Num() < 3) // something's gone wrong, probably a unicode save
			{
				UE_LOG(LogTemp, Warning, TEXT("Error loading config file. Retrying with (hopefully) UTF-16 support."));
				FString UTF16test;
				FFileHelper::LoadFileToString(UTF16test, *configName);
				UTF16test = UTF16test.Replace(TEXT("\r"), TEXT(""));
				UTF16test.ParseIntoArray(configLines, TEXT("\n"), false);
				UTF16test.Empty();
				if (configLines.Num() < 3) // okay, something is definitely wrong
				{
					UE_LOG(LogTemp, Error, TEXT("Critical error loading config file. Loading default config settings."));
					GenerateDefaultSettings();
					return;
				}
			}
			if (configLines.Num() > 1)
			{
				UE_LOG(LogTemp, Log, TEXT("SetupUEr: Reading persistent settings."));
				for (int i = 0; i < configLines.Num(); i++)
				{
					if (configLines[i].StartsWith("ShowSetup="))
						isActive = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
					else
						if (configLines[i].StartsWith("MinUIRes="))
							minResY = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
						else
							if (configLines[i].StartsWith("Commandline="))
							commandLine = configLines[i].RightChop(configLines[i].Find("=") + 1);
						else
							if (configLines[i].StartsWith("Plugins="))
							{
								activePlugins.Empty();
								FString testLine = configLines[i].RightChop(configLines[i].Find("=") + 1);
								testLine.ParseIntoArray(activePlugins, TEXT(","));
								pluginOverride = true;
							}
					if (activePlugins.Contains(cQuality))
					{
						if (configLines[i].StartsWith("Scalability.Resolution="))
							ResolutionQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
						else
							if (configLines[i].StartsWith("Scalability.Shadows="))
								ShadowQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
							else
								if (configLines[i].StartsWith("Scalability.Textures="))
									TextureQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
								else
									if (configLines[i].StartsWith("Scalability.ViewDistance="))
										ViewDistanceQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
									else
										if (configLines[i].StartsWith("Scalability.PostProcess="))
											PostProcessQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
										else
											if (configLines[i].StartsWith("Scalability.Foliage="))
												FoliageQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
											else
												if (configLines[i].StartsWith("Scalability.Effects="))
													EffectsQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
												else
													if (configLines[i].StartsWith("Scalability.AA="))
														AAQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
					}
					if (activePlugins.Contains(cGraphics))
					{
						if (configLines[i].StartsWith("Graphics.ResolutionX="))
							resolutionX = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
						else
							if (configLines[i].StartsWith("Graphics.ResolutionY="))
								resolutionY = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
							else
								if (configLines[i].StartsWith("Graphics.FullscreenMode="))
									fullScreenMode = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
								else
									if (configLines[i].StartsWith("Graphics.VSync="))
										vSync = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
									else
										if (configLines[i].StartsWith("Graphics.Monitor="))
											monitor = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
					}
					if (activePlugins.Contains(cKeyboard))
					{
						if (firstLoad)
						{
							if (configLines[i].StartsWith("Keyboard.AxisRemap="))
							{
								FString tempString = configLines[i].RightChop(configLines[i].Find("=") + 1);
								TArray<FString> brokenUp;
								tempString.ParseIntoArray(brokenUp, TEXT(","));
								if (brokenUp.Num() == 4)
								{
									int index = modifiedAxisMappings.IndexOfByPredicate([&](TSharedPtr<FInputAxisKeyMapping> fia) {return ((fia->AxisName.ToString() == brokenUp[0]) && (fia->Key.ToString() == brokenUp[2])); });
									if ((index > -1) && (index < modifiedAxisMappings.Num()))
									{
										modifiedAxisMappings[index]->Key = ConvertToEKeys(brokenUp[3]);
									}
									else
										UE_LOG(LogTemp, Warning, TEXT("Could not find %s"), *tempString);
								}
								else
									UE_LOG(LogTemp, Warning, TEXT("Could not break up %s"), *tempString);
							}
							else
								if (configLines[i].StartsWith("Keyboard.ActionRemap="))
								{
									FString tempString = configLines[i].RightChop(configLines[i].Find("=") + 1);
									TArray<FString> brokenUp;
									tempString.ParseIntoArray(brokenUp, TEXT(","));
									if (brokenUp.Num() == 3)
									{
										int index = modifiedActionMappings.IndexOfByPredicate([&](TSharedPtr<FInputActionKeyMapping> fia) {return ((fia->ActionName.ToString() == brokenUp[0]) && (fia->Key.ToString() == brokenUp[1])); });
										if ((index > -1) && (index < modifiedActionMappings.Num()))
										{
											modifiedActionMappings[index]->Key = ConvertToEKeys(brokenUp[2]);
										}
										else
											UE_LOG(LogTemp, Warning, TEXT("Could not find %s"), *tempString);
									}
									else
										UE_LOG(LogTemp, Warning, TEXT("Could not break up %s"), *tempString);
								}
						}
						else
						{
							if (configLines[i].StartsWith("Keyboard.AxisRemap="))
							{
								backupAxisMappings.Add(configLines[i]);
							}
							else
								if (configLines[i].StartsWith("Keyboard.ActionRemap="))
								{
									backupActionMappings.Add(configLines[i]);
								}
						}
					}
								
				}
				persistentSettings = true;
			}
		}
	
	}

	static void ClearKeyboardDataInGame()
	{
		backupAxisMappings.Empty();
		backupActionMappings.Empty();
	}

	static void SaveConfig(bool firstLoad = false)
	{
		// generate a new persistent setting file. Doesn't need title and logo
		
		FString configName = FPaths::GameDir() + gameName + ".cfg";
		FString outputString = "";
		outputString += "ShowSetup=" + FString::FromInt((int)isActive) + "\r\n";
		outputString += "Commandline=" + commandLine + "\r\n";
		if (pluginOverride) // keep the plugin override the user did
		{
			outputString += "Plugins=";
			for (int i = 0; i < activePlugins.Num(); i++)
			{
				outputString += activePlugins[i];
				if (i < activePlugins.Num() - 1)
					outputString += ",";
			}
			outputString += "\r\n";
		}
		if (activePlugins.Contains(cQuality))
		{
			outputString += "Scalability.Resolution=" + FString::FromInt(ResolutionQuality) + "\r\n";
			outputString += "Scalability.Shadows=" + FString::FromInt(ShadowQuality) + "\r\n";
			outputString += "Scalability.Textures=" + FString::FromInt(TextureQuality) + "\r\n";
			outputString += "Scalability.ViewDistance="+ FString::FromInt(ViewDistanceQuality) + "\r\n";
			outputString += "Scalability.PostProcess="+FString::FromInt(PostProcessQuality) + "\r\n";
			outputString += "Scalability.Foliage="+FString::FromInt(FoliageQuality) + "\r\n";
			outputString += "Scalability.Effects="+FString::FromInt(EffectsQuality) + "\r\n";
			outputString += "Scalability.AA="+FString::FromInt(AAQuality) + "\r\n";
		}
		if (activePlugins.Contains(cGraphics))
		{
			outputString += "Graphics.FullscreenMode=" + FString::FromInt(fullScreenMode) + "\r\n";
			outputString += "Graphics.ResolutionX=" + FString::FromInt(resolutionX) + "\r\n";
			outputString += "Graphics.ResolutionY=" + FString::FromInt(resolutionY) + "\r\n";
			outputString += "Graphics.VSync=" + FString::FromInt((int)vSync) + "\r\n";
			outputString += "Graphics.Monitor=" + FString::FromInt(monitor) + "\r\n";
		}
		if (activePlugins.Contains(cKeyboard))
		{
			if (firstLoad)
			{
				for (int i = 0; i < modifiedAxisMappings.Num(); i++)
					if (originalAxisMappings[i].Key != modifiedAxisMappings[i]->Key)
						outputString += "Keyboard.AxisRemap=" + originalAxisMappings[i].AxisName.ToString() + "," + FString::SanitizeFloat(originalAxisMappings[i].Scale) + "," + originalAxisMappings[i].Key.ToString() + "," + modifiedAxisMappings[i]->Key.ToString() + "\r\n";

				for (int i = 0; i < modifiedActionMappings.Num(); i++)
					if (originalActionMappings[i].Key != modifiedActionMappings[i]->Key)
						outputString += "Keyboard.ActionRemap=" + originalActionMappings[i].ActionName.ToString() + "," + originalActionMappings[i].Key.ToString() + "," + modifiedActionMappings[i]->Key.ToString() + "\r\n";
			}
			else
			{
				for (int i = 0; i < backupAxisMappings.Num(); i++)
					outputString += backupAxisMappings[i] + "\r\n";

				for (int i = 0; i < backupActionMappings.Num(); i++)
					outputString += backupActionMappings[i] + "\r\n";
			}
		}


		FFileHelper::SaveStringToFile(outputString, *configName);
	}

	static TMap<FString, FKey> GetKeys()
	{
		TMap<FString, FKey> keyMap;
		TArray<FKey> allKeys;
		EKeys::GetAllKeys(allKeys);

		for (const FKey& key : allKeys)
			keyMap.Add(key.ToString(), key);

		return keyMap;
	}


	static FKey ConvertToEKeys(const FString& inputKey) // wwith thanks to Jon Nabozny
	{
		static TMap<FString, FKey> keyMap = GetKeys();

		FKey* key = keyMap.Find(inputKey);
		return key ? *key : EKeys::Invalid;
	}
};

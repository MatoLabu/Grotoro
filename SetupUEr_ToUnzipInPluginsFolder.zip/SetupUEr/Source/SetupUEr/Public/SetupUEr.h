// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once

#include "ModuleManager.h"
#include "Scalability.h"
#include "SlateBasics.h"
#include "ScalabilityWidget.h"
#include "GraphicsSettingsWidget.h"
#include "KeyboardSettingsWidget.h"
#include "SetupUErSettings.h"
#include "Engine.h"
#include "UnrealClient.h"

class FSetupUErModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:

	void FillScaleGraphics()
	{
		Scalability::FQualityLevels CachedQualityLevels = Scalability::GetQualityLevels();
		CachedQualityLevels.ResolutionQuality = SetupUErSettings::ResolutionQuality;
		CachedQualityLevels.ViewDistanceQuality = SetupUErSettings::ViewDistanceQuality;
		CachedQualityLevels.AntiAliasingQuality = SetupUErSettings::AAQuality;
		CachedQualityLevels.PostProcessQuality = SetupUErSettings::PostProcessQuality;
		CachedQualityLevels.ShadowQuality = SetupUErSettings::ShadowQuality;
		CachedQualityLevels.TextureQuality = SetupUErSettings::TextureQuality;
		CachedQualityLevels.EffectsQuality = SetupUErSettings::EffectsQuality;
		CachedQualityLevels.FoliageQuality = SetupUErSettings::FoliageQuality;
		Scalability::SetQualityLevels(CachedQualityLevels);
	}

	void SetGraphics()
	{
		GSystemResolution.WindowMode = (EWindowMode::Type)SetupUErSettings::fullScreenMode;
		if (SetupUErSettings::resolutionX>0)
			GSystemResolution.ResX = SetupUErSettings::resolutionX;
		if (SetupUErSettings::resolutionY>0)
			GSystemResolution.ResY = SetupUErSettings::resolutionY;
		const auto rVSync = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Vsync"));
		int32 Vsync = rVSync->GetInt();
		rVSync->Set(SetupUErSettings::vSync);

		/*		if (GEngine)  // Yes, I know this is the "correct" way to do this. However, the plugin all happens before the engine is actually initialized, so... Can't do this.
		{
		UE_LOG(LogTemp, Log, TEXT("Found GEngine"));
		UGameUserSettings* gameUserSettings = GEngine->GameUserSettings;
		gameUserSettings->SetScreenResolution(FIntPoint(SetupUErSettings::resolutionX, SetupUErSettings::resolutionY));
		gameUserSettings->SetFullscreenMode((EWindowMode::Type)SetupUErSettings::fullScreenMode);
		gameUserSettings->SaveSettings();
		}
		else
		UE_LOG(LogTemp, Error, TEXT("Well, I guess this isn't going to work"));*/

	}

	void SetKeyboard()
	{
		UInputSettings* UIS = GetMutableDefault<UInputSettings>();

		for (int i = 0; i < SetupUErSettings::originalAxisMappings.Num(); i++)
			UIS->RemoveAxisMapping(SetupUErSettings::originalAxisMappings[i]);

		for (int i = 0; i < SetupUErSettings::originalActionMappings.Num(); i++)
			UIS->RemoveActionMapping(SetupUErSettings::originalActionMappings[i]);

		for (int i = 0; i < SetupUErSettings::modifiedAxisMappings.Num(); i++)
			UIS->AddAxisMapping(*SetupUErSettings::modifiedAxisMappings[i]);

		for (int i = 0; i < SetupUErSettings::modifiedActionMappings.Num(); i++)
			UIS->AddActionMapping(*SetupUErSettings::modifiedActionMappings[i]);
	} 

};

struct FSetupUErLogoBrush : public FSlateDynamicImageBrush, public FGCObject
{
	FSetupUErLogoBrush(const FName InTextureName, const FVector2D &InImageSize) :FSlateDynamicImageBrush(InTextureName, InImageSize)
	{
		ResourceObject = LoadObject<UObject>(NULL, *InTextureName.ToString());
		if (!ResourceObject) // Make sure we're actually loading SOMETHING just in case something went wrong with the pak-ed SetupUEr.cfg?
		{
			FString blankTexture = "/Engine/EngineResources/WhiteSquareTexture.WhiteSquareTexture";
			ResourceObject = LoadObject<UObject>(NULL, *blankTexture);
		}
	}

	virtual void AddReferencedObjects(FReferenceCollector &Collector)
	{
		if (ResourceObject)
			Collector.AddReferencedObject(ResourceObject);
	}
};

#define LOCTEXT_NAMESPACE "SSetupUErWidget"
class SSetupUErWidget : public SWindow
{
public:
	SLATE_BEGIN_ARGS(SSetupUErWidget) {}

	SLATE_END_ARGS()

public:
	EAppReturnType::Type GetResult()
	{
		return response;
	}

	TSharedPtr<FSetupUErLogoBrush> logoBrush; 

	BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
	void Construct(const FArguments& InArgs)
	{
		logoBrush = MakeShareable(new FSetupUErLogoBrush(SetupUErSettings::logoName, FVector2D(300, 100)));

		SWindow::Construct(SWindow::FArguments()
			.Title(FText::FromString(" "+SetupUErSettings::title+" ")) // the font renderer sometimes cuts off the rightmost curve of a letter slightly, so let's space it out
			.AutoCenter(EAutoCenter::PreferredWorkArea)
			.ClientSize(FVector2D(350, 455))
			.HasCloseButton(false)
			.FocusWhenFirstShown(true)
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Top)
				.Padding(3.0f, 1.0f)
				[
					SNew(SBox)
					.HeightOverride(100)
					.WidthOverride(300)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					[
						SNew(SImage)
						.Image(logoBrush.Get())
					]
				]
				+SVerticalBox::Slot()
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Fill)
				.AutoHeight()
				.Padding(3.0f, 1.0f)
				[
					SNew(SBox)
					.HAlign(HAlign_Center)
					.WidthOverride(344)
					.HeightOverride(300)
					[
						SNew(SBorder)
						.VAlign(VAlign_Fill)
						.BorderBackgroundColor(FSlateColor(FLinearColor(0.0f, 0.0f, 0.0f, 1.0f)))
						[
							SAssignNew(myScrollBox, SScrollBox)
							.Orientation(EOrientation::Orient_Vertical)
							.ScrollBarAlwaysVisible(false)
						]
					]
				]
				+SVerticalBox::Slot()
				.VAlign(VAlign_Bottom)
				.Padding(3.0f, 1.0f)
				[
					SNew(SVerticalBox)
					+SVerticalBox::Slot()
					.HAlign(HAlign_Fill)
					[
						SNew(SBox)
						.HeightOverride(26)
						[
							SNew(SHorizontalBox)
							+SHorizontalBox::Slot()
							.VAlign(VAlign_Center)
							[
								SNew(STextBlock)
								.Text(LOCTEXT("commandLine", "Commandline: "))
							]
							+ SHorizontalBox::Slot()
							.VAlign(VAlign_Center)
							.AutoWidth()
							[
								SNew(SEditableTextBox)
								.MinDesiredWidth(250)
								.OnTextChanged(this, &SSetupUErWidget::OnCommandLineChanged)
								.Text(this, &SSetupUErWidget::GetCommandLineString)
							]
						]
					]
					+SVerticalBox::Slot()
					[
						SNew(SHorizontalBox)
						+SHorizontalBox::Slot()
						.AutoWidth()
						.HAlign(HAlign_Left)
						[
							SNew(SBox)
							.HeightOverride(26)	
							.WidthOverride(150)
							[
								SNew(SHorizontalBox)
								+ SHorizontalBox::Slot()
								.Padding(3.0f, 1.0f)
								.AutoWidth()
								[
									SNew(SButton)
									.OnClicked(this, &SSetupUErWidget::Launch)
									.Text(LOCTEXT("launch", "Launch game"))
								]
								+ SHorizontalBox::Slot()
								.Padding(3.0f, 1.0f)
								.AutoWidth()
								[
									SNew(SButton)
									.OnClicked(this, &SSetupUErWidget::Abort)
									.Text(LOCTEXT("quit", "Abort"))
								]
							]
						]
						+SHorizontalBox::Slot()
						.FillWidth(1)
						[
							SNew(SSpacer)
						]
						+SHorizontalBox::Slot()
						.AutoWidth()
						[
							SNew(SBox)
							.HAlign(HAlign_Right)
							.HeightOverride(26)
							[
								SNew(SHorizontalBox)
								+SHorizontalBox::Slot()
								.VAlign(VAlign_Center)
								.AutoWidth()
								.Padding(3.0f, 0.0f)
								[
									SNew(STextBlock)
									.Text(LOCTEXT("LoadNext", "Show setup next time"))
								]
								.VAlign(VAlign_Center)
								+SHorizontalBox::Slot()
								[
									SNew(SCheckBox)
									.IsChecked(this, &SSetupUErWidget::GetLoadNextActive)
									.OnCheckStateChanged(this, &SSetupUErWidget::OnLoadNextChanged)
									.ToolTipText(LOCTEXT("LoadNextTooltip", "Show this window the next time the game starts?"))
								]
							]
						]
					]
				]
			]);

			for (int pluginAdd = 0; pluginAdd < SetupUErSettings::activePlugins.Num(); pluginAdd++)
			{
				myScrollBox->AddSlot()
				[
					GeneratePluginSection(SetupUErSettings::activePlugins[pluginAdd])
				];
			}

	}
	END_SLATE_FUNCTION_BUILD_OPTIMIZATION

private:
	EAppReturnType::Type response = EAppReturnType::Ok;
	TSharedPtr<SScrollBox> myScrollBox;

	TSharedRef<SWidget> GetPluginWidget(FString header)
	{
		if (header == cQuality)
		{
			return
				SNew(ScalabilityWidget);
		}
		else
			if (header == cGraphics)
			{
				return
					SNew(GraphicsSettingsWidget);
			}
			else
				if (header == cKeyboard)
				{
					return
						SNew(KeyboardSettingsWidget);
				}
				else
				return
				SNew(STextBlock)
				.Text(LOCTEXT("unknowntype","Unknown plugin type"));
	}

	TSharedRef<SWidget> GeneratePluginSection(FString header)
	{
		return
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				.HeightOverride(20)
				[
					SNew(SHeader)
					.Content()
					[
						SNew(STextBlock)
						.Text(FText::FromString(header))
					]
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				.Padding(FMargin(1.0f, 0.0f))
				[
					GetPluginWidget(header)
				]
			];
	}


	ECheckBoxState GetLoadNextActive() const
	{
		return SetupUErSettings::isActive ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
	}

	void OnLoadNextChanged(ECheckBoxState NewState)
	{
		SetupUErSettings::isActive = (NewState == ECheckBoxState::Checked);
	}

	FReply Launch()
	{
		response = EAppReturnType::Ok;
		RequestDestroyWindow();
		return FReply::Handled();
	}

	FReply Abort()
	{
		response = EAppReturnType::Cancel;
		RequestDestroyWindow();
		return FReply::Handled();
	}

	void OnCommandLineChanged(const FText &InLabel)
	{
		SetupUErSettings::commandLine = InLabel.ToString();
	}

	FText GetCommandLineString() const
	{
		return FText::FromString(SetupUErSettings::commandLine);
	}

};
#undef LOCTEXT_NAMESPACE

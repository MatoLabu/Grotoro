// Generic popup text input box
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErPrivatePCH.h"
#include "STurfInputKeyBox.h"

#define LOCTEXT_NAMESPACE "InputKeyBox"
BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void STurfInputKeyBox::Construct(const FArguments& InArgs)
{
	SWindow::Construct(SWindow::FArguments()
	.Title(InArgs._Title)
	.SupportsMinimize(false)
	.SupportsMaximize(false)
	.HasCloseButton(false)
	.ClientSize(FVector2D(400,50))
	[
		SNew(SBorder)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(LOCTEXT("message","Press any key or click a mouse button on this text."))
		]
	]);

}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION
#undef LOCTEXT_NAMESPACE
// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErPrivatePCH.h"
#include "KeyboardSettingsWidget.h"
#include "SetupUErSettings.h"
#include "Engine.h"
#include "UnrealClient.h"
#include "SlateBasics.h"
#include "SlateExtras.h"
#include "STurfInputKeyBox.h"

#define LOCTEXT_NAMESPACE "KeyboardSettingsWidget"


void KeyboardSettingsWidget::Construct(const FArguments &InArgs)
{
	ChildSlot
	[
		SNew(SVerticalBox)
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.HeightOverride(20)
			[
				SNew(SHeader)
				.HAlign(HAlign_Right)
				.Content()
				[
					SNew(STextBlock)
					.Text(LOCTEXT("qwertyazerty","Quick switch"))
				]
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SHorizontalBox)
			+SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.f, 0.f)
			[
			SNew(SBox)
			.HeightOverride(24)
			.WidthOverride(130)
			[
				SNew(SBorder)
				[
					SNew(SButton)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.ForegroundColor(FSlateColor(FLinearColor::White))
					.ButtonStyle(FCoreStyle::Get(), "NoBorder")
					.OnClicked(this, &KeyboardSettingsWidget::SwitchQwertyAzerty)
					.Text(LOCTEXT("switchQA","Qwerty->Azerty"))
					.ToolTipText(LOCTEXT("tooltip", "Click to quickly switch WASD to ZQSD"))
				]
			]
			]
			+SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.f, 0.f)
			[
				SNew(SBox)
				.HeightOverride(24)
				.WidthOverride(130)
				[
					SNew(SBorder)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						.ForegroundColor(FSlateColor(FLinearColor::White))
						.ButtonStyle(FCoreStyle::Get(), "NoBorder")
						.OnClicked(this, &KeyboardSettingsWidget::SwitchAzertyQwerty)
						.Text(LOCTEXT("switchAQ", "Azerty->Qwerty"))
						.ToolTipText(LOCTEXT("tooltip", "Click to quickly switch ZQSD to WASD"))
					]
				]
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.HeightOverride(20)
			[
				SNew(SHeader)
				.HAlign(HAlign_Right)
				.Content()
				[
					SNew(STextBlock)
					.Text(LOCTEXT("axis", "Axes"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SAssignNew(axisListWidget, SListView<TSharedPtr<FInputAxisKeyMapping>>)
			.ItemHeight(30)
			.ListItemsSource(&SetupUErSettings::modifiedAxisMappings)
			.SelectionMode(ESelectionMode::None)
			.OnGenerateRow(this, &KeyboardSettingsWidget::MakeAxisListViewWidget)
			.HeaderRow(
				SNew(SHeaderRow)
				+ SHeaderRow::Column("name").DefaultLabel(LOCTEXT("header_name", "Name")).HAlignCell(HAlign_Left).HAlignHeader(HAlign_Center).VAlignCell(VAlign_Center).FixedWidth(100)
				+ SHeaderRow::Column("key").DefaultLabel(LOCTEXT("header_key", "Key")).HAlignCell(HAlign_Center).HAlignHeader(HAlign_Center).VAlignCell(VAlign_Center)
				+ SHeaderRow::Column("direction").DefaultLabel(LOCTEXT("header_direction", " ")).HAlignCell(HAlign_Center).HAlignHeader(HAlign_Left).VAlignCell(VAlign_Center).FixedWidth(20)
				)
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.HeightOverride(20)
			[
				SNew(SHeader)
				.HAlign(HAlign_Right)
				.Content()
				[
					SNew(STextBlock)
					.Text(LOCTEXT("actions", "Actions"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SAssignNew(actionListWidget, SListView<TSharedPtr<FInputActionKeyMapping>>)
			.ItemHeight(30)
			.ListItemsSource(&SetupUErSettings::modifiedActionMappings)
			.SelectionMode(ESelectionMode::None)
			.OnGenerateRow(this, &KeyboardSettingsWidget::MakeActionListViewWidget)
			.HeaderRow(
				SNew(SHeaderRow)
				+ SHeaderRow::Column("name").DefaultLabel(LOCTEXT("header_name", "Name")).HAlignCell(HAlign_Left).HAlignHeader(HAlign_Center).VAlignCell(VAlign_Center).FixedWidth(100)
				+ SHeaderRow::Column("key").DefaultLabel(LOCTEXT("header_key", "Key")).HAlignCell(HAlign_Center).HAlignHeader(HAlign_Center).VAlignCell(VAlign_Center)
				)
		]
	];
}

TSharedRef<ITableRow> KeyboardSettingsWidget::MakeAxisListViewWidget(TSharedPtr<FInputAxisKeyMapping> Item, const TSharedRef<STableViewBase> &OwnerTable)
{
	class PluginComboWidget : public SMultiColumnTableRow<TSharedPtr<FInputAxisKeyMapping>>
	{
	public:
		SLATE_BEGIN_ARGS(PluginComboWidget) {}
		SLATE_END_ARGS()

		TSharedPtr<FInputAxisKeyMapping> Item;

		void Construct(const FArguments &InArgs, const TSharedRef<STableViewBase> &InOwnerTable, TSharedPtr<FInputAxisKeyMapping> InItem)
		{
			Item = InItem;
			SMultiColumnTableRow<TSharedPtr<FInputAxisKeyMapping>>::Construct(FSuperRowType::FArguments(), InOwnerTable);
		}

		FText GetName() const
		{
			return FText::FromName(Item->AxisName);
		}

		FText GetKey() const
		{
			return FText::FromString(Item->Key.ToString());
		}

		FReply GetNewKey()
		{
			FString newName = Item->Key.ToString();

			TSharedRef<STurfInputKeyBox> inputBox = SNew(STurfInputKeyBox)
				.Title(FText::FromString("Enter new key"));
			TSharedPtr<SWindow> requiredParent;
			FSlateApplication::Get().AddModalWindow(inputBox, requiredParent);
			if (inputBox->GetResponse() == EAppReturnType::Ok)
			{
				FKey newKey = inputBox->GetKeypress();
				if (newKey != EKeys::Invalid)
					Item->Key = newKey;
				else
				{
					FText error = FText::FromString("Error");
					FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("key_assign_error", "Could not assign key.\r\nReverting."), &error);
				}
			}
			return FReply::Handled();
		}

		TSharedRef<SWidget> GenerateWidgetForColumn(const FName &ColumnName)
		{
			if (ColumnName == "name")
			{
				return SNew(STextBlock)
					.Text(this, &PluginComboWidget::GetName);
			}
			else
				if (ColumnName == "key")
				{
					return SNew(SBox)
					.WidthOverride(140)
					[
						SNew(SBorder)
						[
							SNew(SButton)
							.HAlign(HAlign_Center)
							.ForegroundColor(FSlateColor(FLinearColor::White))
							.ButtonStyle(FCoreStyle::Get(), "NoBorder")
							.OnClicked(this, &PluginComboWidget::GetNewKey)
							.Text(this, &PluginComboWidget::GetKey)
							.ToolTipText(LOCTEXT("tooltip","Click to reassign"))
						]
					];
				}
				else
					if (ColumnName == "direction")
					{
						// if you can figure out how the hell the plugin content dir is supposed to work (judging by the docs saying it's experimental and the fact
						// that one of the plugins I have (Kantan Charts) that uses it keeps throwing up errors in the game log, I'm going with "not"), 
						// or know what in-pak textures you want to use, feel free to use SImage the same way SetupUErEditor does
						if (Item->Scale > 0)
							return SNew(STextBlock)
							.Text(LOCTEXT("+", "+"));
						else
							return SNew(STextBlock)
							.Text(LOCTEXT("-", "-"));
					}
			return
				SNew(STextBlock)
				.Text(FText::FromName(ColumnName));
		}
	};
	return SNew(PluginComboWidget, OwnerTable, Item);
}



TSharedRef<ITableRow> KeyboardSettingsWidget::MakeActionListViewWidget(TSharedPtr<FInputActionKeyMapping> Item, const TSharedRef<STableViewBase> &OwnerTable)
{
	class PluginComboWidget : public SMultiColumnTableRow<TSharedPtr<FInputActionKeyMapping>>
	{
	public:
		SLATE_BEGIN_ARGS(PluginComboWidget) {}
		SLATE_END_ARGS()

			TSharedPtr<FInputActionKeyMapping> Item;

		void Construct(const FArguments &InArgs, const TSharedRef<STableViewBase> &InOwnerTable, TSharedPtr<FInputActionKeyMapping> InItem)
		{
			Item = InItem;
			SMultiColumnTableRow<TSharedPtr<FInputActionKeyMapping>>::Construct(FSuperRowType::FArguments(), InOwnerTable);
		}

		FText GetName() const
		{
			return FText::FromName(Item->ActionName);
		}

		FText GetKey() const
		{
			return FText::FromString(Item->Key.ToString());
		}

		FReply GetNewKey()
		{
			FString newName = Item->Key.ToString();

			TSharedRef<STurfInputKeyBox> inputBox = SNew(STurfInputKeyBox)
				.Title(FText::FromString("Enter new key"));
			TSharedPtr<SWindow> requiredParent;
			FSlateApplication::Get().AddModalWindow(inputBox, requiredParent);
			if (inputBox->GetResponse() == EAppReturnType::Ok)
			{
				FKey newKey = inputBox->GetKeypress();
				if (newKey != EKeys::Invalid)
					Item->Key = newKey;
				else
				{
					FText error = FText::FromString("Error");
					FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("key_assign_error", "Could not assign key.\r\nReverting."), &error);
				}
			}
			return FReply::Handled();
		}

		TSharedRef<SWidget> GenerateWidgetForColumn(const FName &ColumnName)
		{
			if (ColumnName == "name")
			{
				return SNew(STextBlock)
					.Text(this, &PluginComboWidget::GetName);
			}
			else
				if (ColumnName == "key")
				{
					return SNew(SBox)
						.WidthOverride(140)
						[
							SNew(SBorder)
							[
								SNew(SButton)
								.HAlign(HAlign_Center)
						.ForegroundColor(FSlateColor(FLinearColor::White))
						.ButtonStyle(FCoreStyle::Get(), "NoBorder")
						.OnClicked(this, &PluginComboWidget::GetNewKey)
						.Text(this, &PluginComboWidget::GetKey)
						.ToolTipText(LOCTEXT("tooltip", "Click to reassign"))
							]
						];
				}
			return
				SNew(STextBlock)
				.Text(FText::FromName(ColumnName));
		}
	};
	return SNew(PluginComboWidget, OwnerTable, Item);
}
#undef LOCTEXT_NAMESPACE

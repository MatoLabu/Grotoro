// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErPrivatePCH.h"
#include "GraphicsSettingsWidget.h"
#include "SetupUErSettings.h"

#define LOCTEXT_NAMESPACE "GraphicsSettingsWidget"

void GraphicsSettingsWidget::Construct(const FArguments &InArgs)
{
	//find all possible resolutions
	FScreenResolutionArray supportedResolutions;
	resolutions.Empty();
	resolutionList.Empty();
	FString resolutionString;
	if (RHIGetAvailableResolutions(supportedResolutions, true))
	{
		FIntPoint resolution;
		for (const FScreenResolutionRHI& supportedResolution : supportedResolutions)
		{
			if (supportedResolution.Height >= (uint32)SetupUErSettings::minResY) // make sure the UI scale is the lowest resolution we suggest
			{
				resolution.X = supportedResolution.Width;
				resolution.Y = supportedResolution.Height;
				resolutions.Add(resolution);
				resolutionString = FString::FromInt(resolution.X) + " x " + FString::FromInt(resolution.Y);
				resolutionList.Add(MakeShareable(new FString(resolutionString)));
			}
		}
		if (resolutionList.Num() > 0)
		{
			int listIndex = resolutions.IndexOfByPredicate([&](FIntPoint a) {return ((a.X == SetupUErSettings::resolutionX) && (a.Y == SetupUErSettings::resolutionY)); });
			if (listIndex <0)
			{
				resolution.X = SetupUErSettings::resolutionX;
				resolution.Y = SetupUErSettings::resolutionY;
				resolutions.Add(resolution);
				resolutionString = FString::FromInt(resolution.X) + " x " + FString::FromInt(resolution.Y)+ " (current)";
				UE_LOG(LogTemp, Warning, TEXT("SetupUEr: Adding %s"), *resolutionString);
				listIndex = resolutionList.Add(MakeShareable(new FString(resolutionString)));
			}
			initialResSelected = resolutionList[listIndex];
			currentRes = *initialResSelected;
			allowSimpleResolutions = true;
		}
	}

	monitorList.Empty();
	FDisplayMetrics myDisplay;
	FDisplayMetrics::GetDisplayMetrics(myDisplay);
	for (int q = 0; q < myDisplay.MonitorInfo.Num(); q++)
	{
		monitorList.Add(MakeShareable(new FString(myDisplay.MonitorInfo[q].Name + " (" + FString::FromInt(q) + ")")));
	}

	initialMonitorSelected = monitorList[SetupUErSettings::monitor];
	currentMonitor = *initialMonitorSelected;

	windowModeList.Empty();
	resolutionString = "Fullscreen";
	windowModeList.Add(MakeShareable(new FString(resolutionString)));
	resolutionString = "Windowed Fullscreen";
	windowModeList.Add(MakeShareable(new FString(resolutionString)));
	resolutionString = "Windowed";
	windowModeList.Add(MakeShareable(new FString(resolutionString)));
	if (!((SetupUErSettings::fullScreenMode > -1) && (SetupUErSettings::fullScreenMode < 3)))  // something went wrong, default to fullscreen
		SetupUErSettings::fullScreenMode = 0;

	initialWindowModeSelected = windowModeList[SetupUErSettings::fullScreenMode];
	currentWindowMode = *initialWindowModeSelected;

	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.Padding(3.0f, 1.f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.VAlign(VAlign_Center)
					.WidthOverride(150)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("window_mode", "Window mode :"))
					]
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.WidthOverride(150)
					[
						SNew(SComboBox<TSharedPtr<FString>>)
						.OptionsSource(&windowModeList)
						.InitiallySelectedItem(initialWindowModeSelected)
						.OnSelectionChanged(this, &GraphicsSettingsWidget::HandleWindowModeChanged)
						.OnGenerateWidget(this, &GraphicsSettingsWidget::HandleGenerateCombo)
						[
							SNew(STextBlock)
							.Text(this, &GraphicsSettingsWidget::HandleWindowModeText)
						]
					]
				]
			]
		]
		+SVerticalBox::Slot()
		.Padding(3.0f, 1.f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.VAlign(VAlign_Center)
					.WidthOverride(150)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("base_resolution", "Resolution :"))
					]
				]
				+SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.WidthOverride(150)
					[
						SNew(SComboBox<TSharedPtr<FString>>)
						.OptionsSource(&resolutionList)
						.InitiallySelectedItem(initialResSelected)
						.OnSelectionChanged(this, &GraphicsSettingsWidget::HandleResChanged)
						.OnGenerateWidget(this, &GraphicsSettingsWidget::HandleGenerateCombo)
						[
							SNew(STextBlock)
							.Text(this, &GraphicsSettingsWidget::HandleResText)
						]
					]
				]
			]
		]
		+SVerticalBox::Slot()
		.Padding(3.0f, 1.f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.VAlign(VAlign_Center)
					.WidthOverride(150)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("resolution","Custom resolution :"))
					]
				]
				+SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.WidthOverride(150)
					[
						SNew(SHorizontalBox)
						+SHorizontalBox::Slot()
						.AutoWidth()
						[
							SNew(SEditableTextBox)
							.MinDesiredWidth(50)
							.OnTextChanged(this, &GraphicsSettingsWidget::OnResXChanged)
							.Text(this, &GraphicsSettingsWidget::GetResX)
							.ToolTipText(LOCTEXT("resX","Width"))
						]
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.Padding(3.0f,0.f)
						[
							SNew(SBox)
							.VAlign(VAlign_Center)
							.WidthOverride(10)
							[
								SNew(STextBlock)
								.Text(LOCTEXT("x", "x"))
							]
						]
						+ SHorizontalBox::Slot()
						.AutoWidth()
						[
							SNew(SEditableTextBox)
							.MinDesiredWidth(50)
							.OnTextChanged(this, &GraphicsSettingsWidget::OnResYChanged)
							.Text(this, &GraphicsSettingsWidget::GetResY)
							.ToolTipText(LOCTEXT("resY", "Height"))
						]

					]
				]
			]
		]
		+SVerticalBox::Slot()
		.Padding(3.0f, 1.f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[	
					SNew(SBox)
					.VAlign(VAlign_Center)
					.WidthOverride(150)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("vsync", "Use VSync :"))
					]
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[
					SNew(SCheckBox)
					.IsChecked(this, &GraphicsSettingsWidget::UseVSync)
					.OnCheckStateChanged(this, &GraphicsSettingsWidget::SetVSync)
				]
			]
		]
		+ SVerticalBox::Slot()
		.Padding(3.0f, 1.f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Left)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.VAlign(VAlign_Center)
					.WidthOverride(150)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("monitor", "Monitor :"))
					]
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.Padding(3.0f, 0.f)
				[
					SNew(SBox)
					.WidthOverride(150)
					[
						SNew(SComboBox<TSharedPtr<FString>>)
						.OptionsSource(&monitorList)
						.InitiallySelectedItem(initialMonitorSelected)
						.OnSelectionChanged(this, &GraphicsSettingsWidget::HandleMonitorChanged)
						.OnGenerateWidget(this, &GraphicsSettingsWidget::HandleGenerateCombo)
						[
							SNew(STextBlock)
							.Text(this, &GraphicsSettingsWidget::HandleMonitorText)
						]
					]
				]
			]
		]
	];
}

#undef LOCTEXT_NAMESPACE

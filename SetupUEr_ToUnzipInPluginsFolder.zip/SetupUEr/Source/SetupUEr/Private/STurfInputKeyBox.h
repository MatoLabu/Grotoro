// Key input box
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once
#include "SlateBasics.h"
#include "SlateExtras.h"
#include "SetupUErSettings.h"

class STurfInputKeyBox:public SWindow
{
	public:
		SLATE_BEGIN_ARGS(STurfInputKeyBox)	{}
			SLATE_ATTRIBUTE(FText, Title)
		SLATE_END_ARGS()

		void Construct(const FArguments& InArgs);

		EAppReturnType::Type GetResponse()
		{
			return response;
		}

		FKey GetKeypress()
		{
			return fkeyreturn;
		}

	/*	virtual FReply OnControllerButtonPressed(FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
		{
			fkeyreturn = InKeyEvent.GetKey();
			response = EAppReturnType::Ok;
			RequestDestroyWindow();
			return FReply::Handled();
		}
		// probably move these to a separate "controller" widget?

		virtual FReply OnControllerAnalogValueChanged(const FGeometry& MyGeometry, const FAnalogInputEvent& InMotionEvent)
		{
			fkeyreturn = InMotionEvent.GetKey();
			response = EAppReturnType::Ok;
			RequestDestroyWindow();
			return FReply::Handled();
		}*/

		// might move back to using GetKeyboardState and VK_LBUTTON because this one only works when clicking inside the actual window? dunno
		virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& InPointerEvent)
		{
			fkeyreturn = InPointerEvent.GetEffectingButton();
			response = EAppReturnType::Ok;
			RequestDestroyWindow();
			return FReply::Handled();
		}

		virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
		{
			fkeyreturn = InKeyEvent.GetKey();
			if (!SetupUErSettings::allowWonkyKeys)
			{
				int keyCode = InKeyEvent.GetKeyCode();
				switch (keyCode) // there's no EKeys constants for these that I can find? Will probably have to expand this later if people run into weird keyboard layouts
				{
				case 192:   // �
				case 220:	// �
				case 221:   // ^ // does not actually match EKeys::Caret in-game apparently
				case 222:   // �
				case 226:   // <  
					fkeyreturn = EKeys::Invalid;
				}
			}

			/*UE_LOG(LogTemp, Log, TEXT("%s"), *InKeyEvent.ToText().ToString());
			UE_LOG(LogTemp, Log, TEXT("%i"), InKeyEvent.GetKeyCode());*/
			response = EAppReturnType::Ok;
			RequestDestroyWindow();
			return FReply::Handled();
		}

	protected:

		EAppReturnType::Type response;
		FKey fkeyreturn;

};
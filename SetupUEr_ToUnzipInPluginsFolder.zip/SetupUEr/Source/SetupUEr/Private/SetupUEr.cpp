// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.


#include "SetupUErPrivatePCH.h"
#include "Engine.h"
#include "UnrealClient.h"
#include "SlateBasics.h"
#include "SlateExtras.h"
#include "Runtime/Launch/Resources/Version.h" 


#define LOCTEXT_NAMESPACE "FSetupUErModule"

void FSetupUErModule::StartupModule()
{
	if (IsRunningGame())
	{
		const TCHAR* commandLine = FCommandLine::Get();
		FString CL = FString(commandLine);
		SetupUErSettings::LoadConfig(true);

		
		if (SetupUErSettings::isActive || CL.Contains("-setup"))
		{
			TSharedRef<SSetupUErWidget> window = SNew(SSetupUErWidget);
			TSharedPtr<SWindow> requiredParent;
			FSlateApplication::Get().AddModalWindow(window, requiredParent);

			SetupUErSettings::SaveConfig(true);

			if (window->GetResult() == EAppReturnType::Cancel) // we quit, guess someone didn't want to play after all?
				FPlatformMisc::RequestExitWithStatus(true, -1);

			if (CL.Contains("-setup"))
			{
				int index = CL.Find("-setup");
				CL.RemoveAt(index, 6);
			}
		}

		if (CL.Contains("Play in Standalone Game"))  // default PISG adds 1280x720 windowed, so... rebuild the thing
		{ 
			TArray<FString> brokenUp;
			CL.ParseIntoArray(brokenUp, TEXT(" "));
			CL = "";
			for (int i = 0; i < brokenUp.Num(); i++)
			{
				if ((brokenUp[i] != "-ResX=1280") && (brokenUp[i] != "-ResY=720") && (brokenUp[i] != "-windowed"))
					CL += brokenUp[i] + " ";
			}
		}

		UE_LOG(LogTemp, Log, TEXT("Command line: %s"), *CL);
		// take care of our settings, even if we didn't show the setupUEr window
		FillScaleGraphics();
		SetGraphics();
#if ENGINE_MINOR_VERSION == 15 // okay, apparently they changed *something* in the way graphic mode setting is handled, so... we're going to do this the ugly way, I guess
		if (CL.Contains("-ResX") || CL.Contains("-ResY"))
		{
			UE_LOG(LogTemp, Warning, TEXT("SetupUEr: Warning, user overrode the resolutions from the command-line, not trying to override now."));
		}
		else
		{
			CL += " -ResX=" + FString::FromInt(SetupUErSettings::resolutionX) + " -ResY=" + FString::FromInt(SetupUErSettings::resolutionY) +
				(SetupUErSettings::vSync ? (" -VSync") : (" -NoVSync"));
			switch (SetupUErSettings::fullScreenMode)
			{
			case 0:CL += " -FULLSCREEN";
				break;
			case 1:CL += " -FULLSCREEN -WINDOWED";
				break;
			case 2:CL += " -WINDOWED";
				break;
			}
		}
#endif
		SetKeyboard();

		// since we're *before* the actual engine loading and we have no gameport to update, we're doing this via the commandline
		FDisplayMetrics myDisplay;
		FDisplayMetrics::GetDisplayMetrics(myDisplay);
		if ((SetupUErSettings::monitor > -1) && (SetupUErSettings::monitor < myDisplay.MonitorInfo.Num()))
		{
			int offsetX = 0;
			int offsetY = myDisplay.MonitorInfo[SetupUErSettings::monitor].NativeHeight/2;
			// shift to the right to the display we want
			for (int q = 0; q < SetupUErSettings::monitor; q++)
				offsetX += myDisplay.MonitorInfo[q].NativeWidth;
			// adjust so that non-fullscreen modes are centered on screen and don't "stick" to the left edge of the screen
			offsetX += (myDisplay.MonitorInfo[SetupUErSettings::monitor].NativeWidth / 2) - (SetupUErSettings::resolutionX / 2);
			offsetY -= (SetupUErSettings::resolutionY / 2); 
			CL += " -WinX=" + FString::FromInt(offsetX) + " -WinY=" + FString::FromInt(offsetY);
		}
		else
			UE_LOG(LogTemp, Error, TEXT("SetupUEr: Monitor out of range!"));


		SetupUErSettings::commandLine = CL + " " + SetupUErSettings::commandLine;
		FCommandLine::Set(*(SetupUErSettings::commandLine));
	}
}

void FSetupUErModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FSetupUErModule, SetupUEr)
// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once
#include "SetupUErPrivatePCH.h"
#include "Scalability.h"
#include "SlateBasics.h"

class ScalabilityWidget :public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(ScalabilityWidget)
	{}
	SLATE_END_ARGS()

	void Construct(const FArguments &InArgs);

private:

	int32 MaxLevelCount = 4; // expand these to defaults
	int32 TotalWidth = 5;

	// note that from 4.14 there is a 5th level, "Cinematic", but it still just means the same as Epic for our code, so nothing's changed in the 0..3 scale
	const int cMaxScaleValue = 3;
	const float cScaleValueUp = 3.03f;
	const float cScaleValueDown = 0.33f;

	void OnResolutionScaleChanged(float InValue);
	float GetResolutionScale() const;
	FText GetResolutionScaleString() const;

	void OnViewDistanceChanged(float InValue);
	float GetViewDistance() const;
	FText GetViewDistanceString() const;

	void OnAAChanged(float InValue);
	float GetAA() const;
	FText GetAAString() const;

	void OnPPChanged(float InValue);
	float GetPP() const;
	FText GetPPString() const;

	void OnShadowsChanged(float InValue);
	float GetShadows() const;
	FText GetShadowsString() const;

	void OnTexturesChanged(float InValue);
	float GetTextures() const;
	FText GetTexturesString() const;

	void OnEffectsChanged(float InValue);
	float GetEffects() const;
	FText GetEffectsString() const;

	void OnFoliageChanged(float InValue);
	float GetFoliage() const;
	FText GetFoliageString() const;

	FText GetSettingString(int value) const;
	float GetSettingValue(int value) const;

	TSharedRef<SWidget> MakeHeaderButtonWidget(const FText& InName, int32 InQualityLevel, const FText& InToolTip);

	FReply OnHeaderClicked(int32 InQualityLevel);

	SGridPanel::FSlot& MakeGridSlot(int32 InCol, int32 InRow, int32 InColSpan = 1, int32 InRowSpan = 1);

private:
	Scalability::FQualityLevels CachedQualityLevels;

	void SetupUErCache();
	void FillFromSetupUEr();
};
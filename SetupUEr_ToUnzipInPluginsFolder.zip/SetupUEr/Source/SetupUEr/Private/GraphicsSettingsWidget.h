// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once
#include "SetupUErPrivatePCH.h"
#include "SetupUErSettings.h"

class GraphicsSettingsWidget:public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(GraphicsSettingsWidget){}
	SLATE_END_ARGS()
	
	void Construct(const FArguments& InArgs);

private:

	TArray<FIntPoint> resolutions;
	TArray<TSharedPtr<FString>> resolutionList;
	TArray<TSharedPtr<FString>> windowModeList;
	TArray<TSharedPtr<FString>> monitorList;
	TSharedPtr<FString> initialResSelected;
	TSharedPtr<FString> initialWindowModeSelected;
	TSharedPtr<FString> initialMonitorSelected;
	FString currentRes;
	FString currentWindowMode;
	FString currentMonitor;

	bool allowSimpleResolutions = false;

	ECheckBoxState UseVSync() const
	{
		if (SetupUErSettings::vSync)
			return ECheckBoxState::Checked;
		else
			return ECheckBoxState::Unchecked;
	}

	void SetVSync(ECheckBoxState inState)
	{
		SetupUErSettings::vSync = (inState == ECheckBoxState::Checked);
	}


	TSharedRef<SWidget> HandleGenerateCombo(TSharedPtr<FString> inItem)
	{
		return SNew(STextBlock)
			.Text(FText::FromString(*inItem));
	}

	FText HandleResText() const
	{
		return FText::FromString(currentRes);
	}

	void HandleResChanged(TSharedPtr<FString> inSelection, ESelectInfo::Type SelectInfo)
	{
		if (inSelection.IsValid())
		{
			currentRes = *inSelection;
			int index = resolutionList.IndexOfByKey(inSelection);
			if (index > -1)
			{
				SetupUErSettings::resolutionX = resolutions[index].X;
				SetupUErSettings::resolutionY = resolutions[index].Y;
			}
			else
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("This should never ever happen."));
		}
	}

	FText HandleWindowModeText() const
	{
		return FText::FromString(currentWindowMode);
	}

	void HandleWindowModeChanged(TSharedPtr<FString> inSelection, ESelectInfo::Type SelectInfo)
	{
		if (inSelection.IsValid())
		{
			currentWindowMode = *inSelection;
			SetupUErSettings::fullScreenMode = windowModeList.IndexOfByKey(inSelection);
		}
	}

	FText HandleMonitorText() const
	{
		return FText::FromString(currentMonitor);
	}

	void HandleMonitorChanged(TSharedPtr<FString> inSelection, ESelectInfo::Type SelectInfo)
	{
		if (inSelection.IsValid())
		{
			currentMonitor = *inSelection;
			SetupUErSettings::monitor = monitorList.IndexOfByKey(inSelection);
		}
	}

	void OnResXChanged(const FText &InLabel)
	{
		int temp = FCString::Atoi(*InLabel.ToString());
		if ((temp>0)&&(temp<10481))
			SetupUErSettings::resolutionX = temp;
	}

	FText GetResX() const
	{
		return FText::FromString(FString::FromInt(SetupUErSettings::resolutionX));
	}

	void OnResYChanged(const FText &InLabel)
	{
		int temp = FCString::Atoi(*InLabel.ToString());
		if ((temp>0) && (temp<10481))
			SetupUErSettings::resolutionY = temp;
	}

	FText GetResY() const
	{
		return FText::FromString(FString::FromInt(SetupUErSettings::resolutionY));
	}


};
// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once
#include "SetupUErPrivatePCH.h"
#include "SetupUErSettings.h"
#include "Engine.h"
#include "UnrealClient.h"


class KeyboardSettingsWidget :public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(KeyboardSettingsWidget) {}
	SLATE_END_ARGS()

		void Construct(const FArguments& InArgs);

private:

	TSharedPtr<SListView<TSharedPtr<FInputAxisKeyMapping>>> axisListWidget;
	TSharedRef<ITableRow> MakeAxisListViewWidget(TSharedPtr<FInputAxisKeyMapping> Item, const TSharedRef<STableViewBase>& OwnerTable);

	TSharedPtr<SListView<TSharedPtr<FInputActionKeyMapping>>> actionListWidget;
	TSharedRef<ITableRow> MakeActionListViewWidget(TSharedPtr<FInputActionKeyMapping> Item, const TSharedRef<STableViewBase>& OwnerTable);


	FReply SwitchQwertyAzerty()
	{
		for (int i = 0; i < SetupUErSettings::modifiedAxisMappings.Num(); i++)
		{
			if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::A)
				SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Q;
			else
				if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Z)
					SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::W;
				else
					if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Q)
						SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::A;
					else
						if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::W)
							SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Z;
						else
							if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::M)
								SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Comma;
							else
								if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Semicolon)
									SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::M;
		}

		for (int i = 0; i < SetupUErSettings::modifiedActionMappings.Num(); i++)
		{
			if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::A)
				SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Q;
			else
				if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Z)
					SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::W;
				else
					if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Q)
						SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::A;
					else
						if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::W)
							SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Z;
						else
							if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::M)
								SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Comma;
							else
								if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Semicolon)
									SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::M;
		}

		return FReply::Handled();
	}


	FReply SwitchAzertyQwerty()
	{
		for (int i = 0; i < SetupUErSettings::modifiedAxisMappings.Num(); i++)
		{
			if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::A)
				SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Q;
			else
				if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Z)
					SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::W;
				else
					if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Q)
						SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::A;
					else
						if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::W)
							SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Z;
						else
							if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::M) // these damn buggers don't convert back nicely
								SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::Semicolon;
							else
								if (SetupUErSettings::modifiedAxisMappings[i]->Key == EKeys::Comma)
									SetupUErSettings::modifiedAxisMappings[i]->Key = EKeys::M;
		}

		for (int i = 0; i < SetupUErSettings::modifiedActionMappings.Num(); i++)
		{
			if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::A)
				SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Q;
			else
				if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Z)
					SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::W;
				else
					if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Q)
						SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::A;
					else
						if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::W)
							SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Z;
						else
							if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::M) // these damn buggers don't convert back nicely
								SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::Semicolon;
							else
								if (SetupUErSettings::modifiedActionMappings[i]->Key == EKeys::Comma)
									SetupUErSettings::modifiedActionMappings[i]->Key = EKeys::M;
		}

		return FReply::Handled();
	}

};
// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

// v1.1 cleaned up some stuff for the 4.14.0 release, and tightened up the code somewhat

#include "SetupUErPrivatePCH.h"
#include "Scalabilitywidget.h"
#include "Runtime/Launch/Resources/Version.h"

#define LOCTEXT_NAMESPACE "ScalabiltyWidget"

void ScalabilityWidget::FillFromSetupUEr()
{
	CachedQualityLevels.ResolutionQuality = SetupUErSettings::ResolutionQuality;
	CachedQualityLevels.ViewDistanceQuality = SetupUErSettings::ViewDistanceQuality;
	CachedQualityLevels.AntiAliasingQuality = SetupUErSettings::AAQuality;
	CachedQualityLevels.PostProcessQuality = SetupUErSettings::PostProcessQuality;
	CachedQualityLevels.ShadowQuality = SetupUErSettings::ShadowQuality;
	CachedQualityLevels.TextureQuality = SetupUErSettings::TextureQuality;
	CachedQualityLevels.EffectsQuality = SetupUErSettings::EffectsQuality;
	CachedQualityLevels.FoliageQuality = SetupUErSettings::FoliageQuality;
}

void ScalabilityWidget::SetupUErCache()
{
	// do a local copy for the setup later
	SetupUErSettings::ResolutionQuality = CachedQualityLevels.ResolutionQuality;
	SetupUErSettings::ViewDistanceQuality = CachedQualityLevels.ViewDistanceQuality;
	SetupUErSettings::AAQuality = CachedQualityLevels.AntiAliasingQuality;
	SetupUErSettings::PostProcessQuality = CachedQualityLevels.PostProcessQuality;
	SetupUErSettings::ShadowQuality = CachedQualityLevels.ShadowQuality;
	SetupUErSettings::TextureQuality = CachedQualityLevels.TextureQuality;
	SetupUErSettings::EffectsQuality = CachedQualityLevels.EffectsQuality;
	SetupUErSettings::FoliageQuality = CachedQualityLevels.FoliageQuality;
}

void ScalabilityWidget::OnResolutionScaleChanged(float InValue)
{
	CachedQualityLevels.ResolutionQuality = FMath::Lerp(Scalability::MinResolutionScale, Scalability::MaxResolutionScale, InValue);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni); // this does not actually seem to do anything, because the engine isn't actually loaded yet when we work?
}

float ScalabilityWidget::GetResolutionScale() const
{
	return (float)(CachedQualityLevels.ResolutionQuality - Scalability::MinResolutionScale) / (float)(Scalability::MaxResolutionScale - Scalability::MinResolutionScale);
}


FText ScalabilityWidget::GetResolutionScaleString() const
{
	return FText::AsPercent(FMath::Square(CachedQualityLevels.ResolutionQuality / 100.0f));
}

void ScalabilityWidget::OnViewDistanceChanged(float InValue)
{
	CachedQualityLevels.ViewDistanceQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetViewDistance() const
{
	return GetSettingValue(CachedQualityLevels.ViewDistanceQuality);
}

FText ScalabilityWidget::GetViewDistanceString() const
{
	switch (CachedQualityLevels.ViewDistanceQuality)
	{
	case 0: return LOCTEXT("ViewDistance0", "Near");
	case 1: return LOCTEXT("ViewDistance1", "Med");
	case 2: return LOCTEXT("ViewDistance2", "Far");
	case 3: return LOCTEXT("ViewDistance3", "Epic");
	case 4: return LOCTEXT("ViewDistance4", "Cine");
	}
	return LOCTEXT("unknown", "Undef");
}

void ScalabilityWidget::OnAAChanged(float InValue)
{
	CachedQualityLevels.AntiAliasingQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetAA() const
{
	return GetSettingValue(CachedQualityLevels.AntiAliasingQuality);
}

FText ScalabilityWidget::GetAAString() const
{
	return GetSettingString(CachedQualityLevels.AntiAliasingQuality);
}

void ScalabilityWidget::OnPPChanged(float InValue)
{
	CachedQualityLevels.PostProcessQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetPP() const
{
	return GetSettingValue(CachedQualityLevels.PostProcessQuality);
}

FText ScalabilityWidget::GetPPString() const
{
	return GetSettingString(CachedQualityLevels.PostProcessQuality);
}

void ScalabilityWidget::OnShadowsChanged(float InValue)
{
	CachedQualityLevels.ShadowQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetShadows() const
{
	return GetSettingValue(CachedQualityLevels.ShadowQuality);
}

FText ScalabilityWidget::GetShadowsString() const
{
	return GetSettingString(CachedQualityLevels.ShadowQuality);
}

void ScalabilityWidget::OnTexturesChanged(float InValue)
{
	CachedQualityLevels.TextureQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetTextures() const
{
	return GetSettingValue(CachedQualityLevels.TextureQuality);
}

FText ScalabilityWidget::GetTexturesString() const
{
	return GetSettingString(CachedQualityLevels.TextureQuality);
}

void ScalabilityWidget::OnEffectsChanged(float InValue)
{
	CachedQualityLevels.EffectsQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetEffects() const
{
	return GetSettingValue(CachedQualityLevels.EffectsQuality);
}

FText ScalabilityWidget::GetEffectsString() const
{
	return GetSettingString(CachedQualityLevels.EffectsQuality);
}

void ScalabilityWidget::OnFoliageChanged(float InValue)
{
	CachedQualityLevels.FoliageQuality = (int)(InValue*cScaleValueUp);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
}

float ScalabilityWidget::GetFoliage() const
{
	return GetSettingValue(CachedQualityLevels.FoliageQuality);
}

FText ScalabilityWidget::GetFoliageString() const
{
	return GetSettingString(CachedQualityLevels.FoliageQuality);
}

float ScalabilityWidget::GetSettingValue(int value) const
{
	if (value >= cMaxScaleValue)
		return 1.f;
	else
		return value * cScaleValueDown;
}

FText ScalabilityWidget::GetSettingString(int value) const
{
	switch (value)
	{
	case 0: return LOCTEXT("Setting0", "Low");
	case 1: return LOCTEXT("Setting1", "Med");
	case 2: return LOCTEXT("Setting2", "High");
	case 3: return LOCTEXT("Setting3", "Epic"); // not quite ready for the eventuality of finer granularity, but we'll bomb that bridge when we get there
	case 4: return LOCTEXT("Setting4", "Cine");
	}
	return LOCTEXT("unknown", "Undef");
}

TSharedRef<SWidget> ScalabilityWidget::MakeHeaderButtonWidget(const FText& InName, int32 InQualityLevel, const FText& InToolTip)
{
	return SNew(SBorder)
		[
			SNew(SButton)
			.ForegroundColor(FSlateColor(FLinearColor::White))
			.ButtonStyle(FCoreStyle::Get(), "NoBorder")
			.OnClicked(this, &ScalabilityWidget::OnHeaderClicked, InQualityLevel)
			.ToolTipText(InToolTip)
			.Content()
			[
				SNew(STextBlock)
				.Text(InName)
			]
		];
}

FReply ScalabilityWidget::OnHeaderClicked(int32 InQualityLevel)
{
	CachedQualityLevels.SetFromSingleQualityLevel(InQualityLevel);
	Scalability::SetQualityLevels(CachedQualityLevels);

	SetupUErCache();
	Scalability::SaveState(GGameUserSettingsIni);
	return FReply::Handled();
}

SGridPanel::FSlot& ScalabilityWidget::MakeGridSlot(int32 InCol, int32 InRow, int32 InColSpan /*= 1*/, int32 InRowSpan /*= 1*/)
{
	float PaddingH = 2.0f;
	float PaddingV = InRow == 0 ? 4.0f : 2.0f;
	return SGridPanel::Slot(InCol, InRow)
		.Padding(PaddingH, PaddingV)
		.RowSpan(InRowSpan)
		.ColumnSpan(InColSpan);
}

void ScalabilityWidget::Construct(const FArguments& InArgs)
{
	const FText NamesLow(LOCTEXT("QualityLowLabel", "Low"));
#if ENGINE_MINOR_VERSION >13
	const FText NamesMedium(LOCTEXT("QualityMediumLabel", "Med"));
#else 
	const FText NamesMedium(LOCTEXT("QualityMediumLabel", "Medium"));
#endif
	const FText NamesHigh(LOCTEXT("QualityHighLabel", "High"));
	const FText NamesEpic(LOCTEXT("QualityEpicLabel", "Epic"));
	const FText NamesCinematic(LOCTEXT("QualityCinematicLabel", "Cine"));
	
	CachedQualityLevels = Scalability::GetQualityLevels();
	FillFromSetupUEr();
	static float Padding = 1.0f;
	static float QualityColumnCoeff = 1.0f;
	static float QualityLevelColumnCoeff = 0.2f;
#if ENGINE_MINOR_VERSION >=13
	Scalability::FQualityLevels LevelCounts = Scalability::GetQualityLevelCounts();
	MaxLevelCount =
		FMath::Max(LevelCounts.ShadowQuality,
			FMath::Max(LevelCounts.TextureQuality,
				FMath::Max(LevelCounts.ViewDistanceQuality,
					FMath::Max(LevelCounts.EffectsQuality,
						FMath::Max(LevelCounts.PostProcessQuality, LevelCounts.AntiAliasingQuality)
						))));
	TotalWidth = MaxLevelCount + 1;
#else
	Scalability::FQualityLevels LevelCounts = Scalability::GetQualityLevels();
#endif

	TSharedRef<SGridPanel> SliderMatrix =
		SNew(SGridPanel)
		.FillColumn(0, QualityColumnCoeff)
		+ MakeGridSlot(0, 1, TotalWidth, 1)
		+ MakeGridSlot(0, 2, TotalWidth, 1)
		+ MakeGridSlot(0, 3, TotalWidth, 1)
		+ MakeGridSlot(0, 4, TotalWidth, 1)
		+ MakeGridSlot(0, 5, TotalWidth, 1)
		+ MakeGridSlot(0, 6, TotalWidth, 1)
		+ MakeGridSlot(0, 7, TotalWidth, 1)
		+ MakeGridSlot(0, 8, TotalWidth, 1)

		+ MakeGridSlot(0, 0).VAlign(VAlign_Center)[SNew(STextBlock).Text(LOCTEXT("QualityLabel", "Quality"))]
		+ MakeGridSlot(1, 0)[MakeHeaderButtonWidget(NamesLow, 0, LOCTEXT("QualityLow", "Set all groups to low quality"))]
		+ MakeGridSlot(2, 0)[MakeHeaderButtonWidget(NamesMedium, 1, LOCTEXT("QualityMedium", "Set all groups to medium quality"))]
		+ MakeGridSlot(3, 0)[MakeHeaderButtonWidget(NamesHigh, 2, LOCTEXT("QualityHigh", "Set all groups to high quality"))]
		+ MakeGridSlot(4, 0)[MakeHeaderButtonWidget(NamesEpic, 3, LOCTEXT("QualityEpic", "Set all groups to epic quality"))] // let's hardcode all of these
#if ENGINE_MINOR_VERSION >13
																															 // because for all intents and purposes
																															 // this one has the same functionality as epic
		+ MakeGridSlot(5, 0)[MakeHeaderButtonWidget(NamesCinematic, 4, LOCTEXT("QualityCinematic", "Set all groups to offline cinematic quality\r\nNote that this is the only way to set this quality level"))] 
#endif

		+ MakeGridSlot(0, 1)[SNew(STextBlock).Text(LOCTEXT("ResScaleLabel1", "Resolution Scale"))]
		+ MakeGridSlot(5, 1)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetResolutionScaleString)]]
		+ MakeGridSlot(1, 1, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnResolutionScaleChanged).Value(this, &ScalabilityWidget::GetResolutionScale)]

		+ MakeGridSlot(0, 2)[SNew(STextBlock).Text(LOCTEXT("ViewDistanceLabel1", "View Distance"))]
		+ MakeGridSlot(0, 3)[SNew(STextBlock).Text(LOCTEXT("AntiAliasingQualityLabel1", "Anti-Aliasing"))]
		+ MakeGridSlot(0, 4)[SNew(STextBlock).Text(LOCTEXT("PostProcessQualityLabel1", "Post Processing"))]
		+ MakeGridSlot(0, 5)[SNew(STextBlock).Text(LOCTEXT("ShadowLabel1", "Shadows"))]
		+ MakeGridSlot(0, 6)[SNew(STextBlock).Text(LOCTEXT("TextureQualityLabel1", "Textures"))]
		+ MakeGridSlot(0, 7)[SNew(STextBlock).Text(LOCTEXT("EffectsQualityLabel1", "Effects"))]
		+ MakeGridSlot(0, 8)[SNew(STextBlock).Text(LOCTEXT("FoliageQualityLabel1", "Foliage"))]

		+ MakeGridSlot(1, 2, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnViewDistanceChanged).Value(this, &ScalabilityWidget::GetViewDistance)]
		+ MakeGridSlot(5, 2)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetViewDistanceString)]]
		+ MakeGridSlot(1, 3, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnAAChanged).Value(this, &ScalabilityWidget::GetAA)]
		+ MakeGridSlot(5, 3)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetAAString)]]
		+ MakeGridSlot(1, 4, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnPPChanged).Value(this, &ScalabilityWidget::GetPP)]
		+ MakeGridSlot(5, 4)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetPPString)]]
		+ MakeGridSlot(1, 5, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnShadowsChanged).Value(this, &ScalabilityWidget::GetShadows)]
		+ MakeGridSlot(5, 5)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetShadowsString)]]
		+ MakeGridSlot(1, 6, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnTexturesChanged).Value(this, &ScalabilityWidget::GetTextures)]
		+ MakeGridSlot(5, 6)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetTexturesString)]]
		+ MakeGridSlot(1, 7, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnEffectsChanged).Value(this, &ScalabilityWidget::GetEffects)]
		+ MakeGridSlot(5, 7)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetEffectsString)]]
		+ MakeGridSlot(1, 8, 4, 1)[SNew(SSlider).OnValueChanged(this, &ScalabilityWidget::OnFoliageChanged).Value(this, &ScalabilityWidget::GetFoliage)]
		+ MakeGridSlot(5, 8)[SNew(SBox).WidthOverride(30)[SNew(STextBlock).Text(this, &ScalabilityWidget::GetFoliageString)]]
		;

	this->ChildSlot
		.HAlign(EHorizontalAlignment::HAlign_Fill)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			[
				SliderMatrix
			]
		];
}

#undef LOCTEXT_NAMESPACE

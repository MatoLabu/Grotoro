// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.


#include "SetupUErBPLibraryPrivatePCH.h"
#include "SetupUErBPLibraryBPLibrary.h"

USetupUErBPLibraryBPLibrary::USetupUErBPLibraryBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

void USetupUErBPLibraryBPLibrary::ClearSetupUErKeyboardData(UPARAM(ref) FSetupUErInformation& data)
{
	data.modifiedAxisMappings.Empty();
	data.modifiedActionMappings.Empty();
	UE_LOG(LogTemp, Log, TEXT("SetupUEr: Cleared Keyboard data"));
}

void USetupUErBPLibraryBPLibrary::SaveSetupUEr(UPARAM(ref) FSetupUErInformation data)
{
	FString configName = FPaths::GameDir() + data.gameName + ".cfg";
	FString outputString = "";
	outputString += "ShowSetup=" + FString::FromInt((int)data.isActive) + "\r\n";
	outputString += "Commandline=" + data.commandLine + "\r\n";
	if (data.pluginOverride) // keep the plugin override the user did
	{
		outputString += "Plugins=";
		for (int i = 0; i < data.activePlugins.Num(); i++)
		{
			outputString += data.activePlugins[i];
			if (i < data.activePlugins.Num() - 1)
				outputString += ",";
		}
		outputString += "\r\n";
	}
	if (data.activePlugins.Contains(cQuality))
	{
		outputString += "Scalability.Resolution=" + FString::FromInt(data.ResolutionQuality) + "\r\n";
		outputString += "Scalability.Shadows=" + FString::FromInt(data.ShadowQuality) + "\r\n";
		outputString += "Scalability.Textures=" + FString::FromInt(data.TextureQuality) + "\r\n";
		outputString += "Scalability.ViewDistance=" + FString::FromInt(data.ViewDistanceQuality) + "\r\n";
		outputString += "Scalability.PostProcess=" + FString::FromInt(data.PostProcessQuality) + "\r\n";
		outputString += "Scalability.Foliage=" + FString::FromInt(data.FoliageQuality) + "\r\n";
		outputString += "Scalability.Effects=" + FString::FromInt(data.EffectsQuality) + "\r\n";
		outputString += "Scalability.AA=" + FString::FromInt(data.AAQuality) + "\r\n";
	}
	if (data.activePlugins.Contains(cGraphics))
	{
		outputString += "Graphics.FullscreenMode=" + FString::FromInt(data.fullScreenMode) + "\r\n";
		outputString += "Graphics.ResolutionX=" + FString::FromInt(data.resolutionX) + "\r\n";
		outputString += "Graphics.ResolutionY=" + FString::FromInt(data.resolutionY) + "\r\n";
		outputString += "Graphics.VSync=" + FString::FromInt((int)data.vSync) + "\r\n";
		outputString += "Graphics.Monitor=" + FString::FromInt(data.monitor) + "\r\n";
	}
	if (data.activePlugins.Contains(cKeyboard))
	{
		for (int i = 0; i < data.modifiedAxisMappings.Num(); i++)
			outputString += data.modifiedAxisMappings[i] + "\r\n";

		for (int i = 0; i < data.modifiedActionMappings.Num(); i++)
			outputString += data.modifiedActionMappings[i] + "\r\n";
	}

	FFileHelper::SaveStringToFile(outputString, *configName);
}

FSetupUErInformation USetupUErBPLibraryBPLibrary::LoadSetupUEr()
{
	FSetupUErInformation myData;
	myData.gameName = FPaths::GameDir();
	myData.gameName.RemoveFromEnd("/");
	myData.gameName = myData.gameName.RightChop(myData.gameName.Find("/", ESearchCase::IgnoreCase, ESearchDir::FromEnd) + 1);
	myData.title = "Uninitialized.";

	myData.modifiedAxisMappings.Empty();
	myData.modifiedActionMappings.Empty();

	bool persistentSettings = false;
	myData.pluginOverride = false;



	// check if we have a game-specific config file?
	FString configName = FPaths::GameDir() + myData.gameName + ".cfg";
	TArray<FString> configLines;
	if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
	{
		persistentSettings = true;
	}

	// read the main settings
	configName = FPaths::GameConfigDir() + "SetupUEr.cfg";
	if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
	{
		configLines.Empty();
		FFileHelper::LoadANSITextFileToStrings(*(configName), NULL, configLines);
		if (configLines.Num() < 3) // something's gone wrong, probably a unicode save
		{
			UE_LOG(LogTemp, Warning, TEXT("Error loading config file. Retrying with (hopefully) UTF-16 support."));
			FString UTF16test;
			FFileHelper::LoadFileToString(UTF16test, *configName);
			UTF16test = UTF16test.Replace(TEXT("\r"), TEXT(""));
			UTF16test.ParseIntoArray(configLines, TEXT("\n"), false);
			UTF16test.Empty();
			if (configLines.Num() < 3) // okay, something is definitely wrong
			{
				UE_LOG(LogTemp, Error, TEXT("Critical error loading config file. Loading default config settings."));
				myData.isActive = false;
				myData.minResY = 720;
				myData.title = "U N T I T L E D";
				myData.activePlugins.Add(cGraphics);
			}
		}
		if (configLines.Num() == 7)
		{
			UE_LOG(LogTemp, Log, TEXT("SetupUEr: Reading basic config file."));
			myData.title = configLines[1];
			myData.logoName = FName(*configLines[2]);
			if (!persistentSettings)
			{
				UE_LOG(LogTemp, Log, TEXT("SetupUEr: No persistent settings found. First run?"));
				myData.isActive = (FCString::Atoi(*configLines[0]) == 1) ? true : false;
				myData.commandLine = configLines[3];
				myData.minResY = (FCString::Atoi(*configLines[5]));
			}

			configLines[4].ParseIntoArray(myData.activePlugins, TEXT(","));

			if (myData.activePlugins.Num() == 0)
				myData.activePlugins.Add(cGraphics);
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("SetupUEr: No settings found. Make sure you've set up your SetupUEr data in-editor!"));
			myData.isActive = false;
			myData.minResY = 720;
			myData.title = "U N T I T L E D";
			myData.activePlugins.Add(cGraphics);
		}
	}

	// test for our own settings, since UE's ini config handling stuff is arcane and a total mess... so we'll just duplicate everything
	configName = FPaths::GameDir() + myData.gameName + ".cfg";
	if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
	{
		configLines.Empty();
		FFileHelper::LoadANSITextFileToStrings(*(configName), NULL, configLines);
		if (configLines.Num() > 0)
		{
			UE_LOG(LogTemp, Log, TEXT("SetupUEr: Reading persistent settings."));
			for (int i = 0; i < configLines.Num(); i++)
			{
				if (configLines[i].StartsWith("ShowSetup="))
					myData.isActive = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
				else
					if (configLines[i].StartsWith("MinUIRes="))
						myData.minResY = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
					else
						if (configLines[i].StartsWith("Commandline="))
							myData.commandLine = configLines[i].RightChop(configLines[i].Find("=") + 1);
						else
							if (configLines[i].StartsWith("Plugins="))
							{
								myData.activePlugins.Empty();
								FString testLine = configLines[i].RightChop(configLines[i].Find("=") + 1);
								testLine.ParseIntoArray(myData.activePlugins, TEXT(","));
								myData.pluginOverride = true;
							}
				if (myData.activePlugins.Contains(cQuality))
				{
					if (configLines[i].StartsWith("Scalability.Resolution="))
						myData.ResolutionQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
					else
						if (configLines[i].StartsWith("Scalability.Shadows="))
							myData.ShadowQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
						else
							if (configLines[i].StartsWith("Scalability.Textures="))
								myData.TextureQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
							else
								if (configLines[i].StartsWith("Scalability.ViewDistance="))
									myData.ViewDistanceQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
								else
									if (configLines[i].StartsWith("Scalability.PostProcess="))
										myData.PostProcessQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
									else
										if (configLines[i].StartsWith("Scalability.Foliage="))
											myData.FoliageQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
										else
											if (configLines[i].StartsWith("Scalability.Effects="))
												myData.EffectsQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
											else
												if (configLines[i].StartsWith("Scalability.AA="))
													myData.AAQuality = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
				}
				if (myData.activePlugins.Contains(cGraphics))
				{
					if (configLines[i].StartsWith("Graphics.ResolutionX="))
						myData.resolutionX = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
					else
						if (configLines[i].StartsWith("Graphics.ResolutionY="))
							myData.resolutionY = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
						else
							if (configLines[i].StartsWith("Graphics.FullscreenMode="))
								myData.fullScreenMode = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
							else
								if (configLines[i].StartsWith("Graphics.VSync="))
									myData.vSync = (FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1))) == 1);
								else
									if (configLines[i].StartsWith("Graphics.Monitor="))
										myData.monitor = FCString::Atoi(*(configLines[i].RightChop(configLines[i].Find("=") + 1)));
				}
				if (myData.activePlugins.Contains(cKeyboard))
				{
					if (configLines[i].StartsWith("Keyboard.AxisRemap="))
					{
						myData.modifiedAxisMappings.Add(configLines[i]);
					}
					else
						if (configLines[i].StartsWith("Keyboard.ActionRemap="))
						{
							myData.modifiedActionMappings.Add(configLines[i]);
						}
				}

			}
			persistentSettings = true;
		}
	}

	return myData;
}


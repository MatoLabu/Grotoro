// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.


#pragma once

#include "ModuleManager.h"

class FSetupUErBPLibraryModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
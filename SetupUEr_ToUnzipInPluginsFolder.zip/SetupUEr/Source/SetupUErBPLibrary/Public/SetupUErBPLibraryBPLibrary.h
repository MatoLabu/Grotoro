// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once

#include "Engine.h"
#include "SetupUErBPLibraryBPLibrary.generated.h"

// plugin types
static const FString cGraphics = "Graphics";
static const FString cQuality = "Quality";
static const FString cKeyboard = "Keyboard";

USTRUCT(BlueprintType)
struct FSetupUErInformation
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "SetupUEr window title"))
	FString title;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Command line to pass"))
	FString commandLine;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "SetupUEr logo texture"))
	FName logoName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Show SetupUEr at start?"))
	bool isActive;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "SetupUEr active plugins"))
	TArray<FString> activePlugins;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Current game name"))
	FString gameName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Minimum UI res"))
	int minResY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Resolution Width"))
	int resolutionX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Resolution Height"))
	int resolutionY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Fullscreen mode (0-2 for Fullscreen, Windowed Fullscreen, Windowed)"))
	int fullScreenMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Use Vsync"))
	bool vSync;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Monitor to use"))
	int monitor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Anti-aliasing Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int AAQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Effects Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int EffectsQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Foliage Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int FoliageQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Post-processing Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int PostProcessQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Resolution Scale Setting (0-100)"))
	int ResolutionQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Shadow Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int ShadowQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Texture Quality Setting (0-3 for Low, Medium, Far, Epic)"))
	int TextureQuality;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "View Distance Quality Setting (0-3 for Near, Medium, Far, Epic)"))
	int ViewDistanceQuality;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Axis reassignment data. Do *not* edit this manually."))
	TArray<FString> modifiedAxisMappings;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Action reassignment data. Do *not* edit this manually."))
	TArray<FString> modifiedActionMappings;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool pluginOverride;
};


UCLASS()
class USetupUErBPLibraryBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()
public:
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Load SetupUEr configuration\nCall me before using anything else in this category."), Category = "SetupUEr")
	static FSetupUErInformation LoadSetupUEr();

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Save SetupUEr configuration\nCall me after you've changed any settings SetupUEr might override."), Category = "SetupUEr")
	static void SaveSetupUEr(UPARAM(ref) FSetupUErInformation data);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Clear SetupUEr keyboard rebinds\nCall this if you've used something else to reset your keyboard bindings."), Category = "SetupUEr")
	static void ClearSetupUErKeyboardData(UPARAM(ref) FSetupUErInformation& data);
};

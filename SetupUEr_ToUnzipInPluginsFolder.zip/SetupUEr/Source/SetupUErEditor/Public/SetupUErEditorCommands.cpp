// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErEditorPrivatePCH.h"
#include "SetupUErEditorCommands.h"

#define LOCTEXT_NAMESPACE "FSetupUErEditorModule"

void FSetupUErEditorCommands::RegisterCommands()
{
	UI_COMMAND(OpenPluginWindow, "SetupUEr", "Bring up the SetupUEr editor window\r\nallowing you to adjust your basic settings.", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE

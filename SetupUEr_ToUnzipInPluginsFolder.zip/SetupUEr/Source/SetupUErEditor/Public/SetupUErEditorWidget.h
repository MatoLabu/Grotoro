// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once

#include "SetupUErEditorPrivatePCH.h"

#include "SlateBasics.h"
#include "SlateExtras.h"
#include "SetupUErEditorStyle.h"
#include "UnrealEd.h"

#include "SetupUErSettingsEditor.h"

DECLARE_DELEGATE_OneParam(DoUpdateDelegate, bool);
DECLARE_DELEGATE_TwoParams(DoMoveDelegate, int, bool);

static const int cDisabledPlugin = 255;


enum SetupUErPluginType :int
{ // add your plugins here
	ScaleGraphics,
	Keyboard,
	Graphics,
	Undefined
};

class PluginListEntry :public TSharedFromThis<PluginListEntry>
{
public:
	SetupUErPluginType myType;
	int order;
	bool isActive;
	bool lastActive;
	bool lastItem;

	PluginListEntry()
	{
		myType = SetupUErPluginType::Undefined;
		isActive = false;
		lastActive = false;
		lastItem = false;
		order = cDisabledPlugin;
	}

	PluginListEntry(int ord, FString inType, bool inActive)
	{
		order = ord;
		isActive = inActive; // add your plugins here
		if (inType == cQuality)
			myType = SetupUErPluginType::ScaleGraphics;
		else
			if (inType == cKeyboard)
				myType = SetupUErPluginType::Keyboard;
			else
				if (inType == cGraphics)
					myType = SetupUErPluginType::Graphics;
				else
					myType = SetupUErPluginType::Undefined;
	}

	FString PluginType()
	{
		switch (myType)
		{
			case SetupUErPluginType::ScaleGraphics:
				return cQuality;
				break;
			case SetupUErPluginType::Keyboard:
				return cKeyboard;
				break;
			case SetupUErPluginType::Graphics:
				return cGraphics;
				break;
		}
		return "Undefined";
	}
};

class SetupUErEditorWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SetupUErEditorWidget) {}

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);


private:

	TSharedPtr<FSlateDynamicImageBrush> logoBrush;

	const FVector2D logoSize = FVector2D(300, 100);

	UTexture2D* logoTexture;
	TSharedPtr<SListView<TSharedPtr<PluginListEntry>>> pluginListWidget;
	TArray<TSharedPtr<PluginListEntry>> pluginsList;
	TSharedRef<ITableRow> MakeListViewWidget(TSharedPtr<PluginListEntry> Item, const TSharedRef<STableViewBase>& OwnerTable);

	void DoMoveUpDown(int index, bool moveUp)
	{
		if ((index > -1) && (index < pluginsList.Num()))
		{
			if (moveUp)
			{
				if (index > 0) // yes this should be taken care of in the actual enabling code. Still, safe>>>>>sorry
				{
					int oldIdx = pluginsList[index - 1]->order;
					pluginsList[index - 1]->order = pluginsList[index]->order;
					pluginsList[index]->order = oldIdx;
				}
			}
			else
			{
				if (index < pluginsList.Num() - 1)
				{
					int oldIdx = pluginsList[index + 1]->order;
					pluginsList[index + 1]->order = pluginsList[index]->order;
					pluginsList[index]->order = oldIdx;
				}
			}
		}
		DoReorder();
	}

	void DoReorder(bool doRefresh = true)
	{
		int activeCount = 0;
		int highest = 0;
		for (int i = 0; i < pluginsList.Num(); i++)
		{
			if (pluginsList[i]->isActive)
			{
				activeCount++;
				if (pluginsList[i]->order != cDisabledPlugin)
					highest = FMath::Max(highest, pluginsList[i]->order);

			}
			else
				pluginsList[i]->order = cDisabledPlugin;
		}

		for (int i = 0; i < pluginsList.Num(); i++)
		{
			pluginsList[i]->lastActive = false;
			pluginsList[i]->lastItem = false;
			if (pluginsList[i]->isActive && pluginsList[i]->order == cDisabledPlugin)
				pluginsList[i]->order = ++highest;
		}

		if (activeCount == 0)
			for (int i = 0; i < pluginsList.Num(); i++)
			{
				if (pluginsList[i]->myType == SetupUErPluginType::Graphics)
				{
					pluginsList[i]->isActive = true;
					pluginsList[i]->order = 0;
				}
			}
		pluginsList.Sort([&](TSharedPtr<PluginListEntry> a, TSharedPtr<PluginListEntry> b) {if (a->isActive && b->isActive) return (a->order < b->order); else if (a->isActive) return true; else if (b->isActive) return false; else return false;});

		for (int i = pluginsList.Num() - 1; i >= 0; i--)
		{
			if (pluginsList[i]->isActive)
			{
				pluginsList[i]->order = i;
				if ((i < pluginsList.Num() - 1) && !pluginsList[i + 1]->isActive)
					pluginsList[i]->lastActive = true;
			}
		}

		pluginsList[pluginsList.Num() - 1]->lastItem = true;
		// rebuild the list
		SetupUErSettings::activePlugins.Empty();
		for (int i = 0; i < pluginsList.Num(); i++)
		{
			if (pluginsList[i]->isActive)
				SetupUErSettings::activePlugins.Add(pluginsList[i]->PluginType());
		}
		if (doRefresh)
			pluginListWidget->RequestListRefresh();
	}

	FReply DoSaveSettings()
	{
		SetupUErSettings::SaveConfig();
		return FReply::Handled();
	}

	void OnGameNameChanged(const FText &InLabel)
	{
		SetupUErSettings::title = InLabel.ToString();
	}

	FText GetGameNameString() const
	{
		return FText::FromString(SetupUErSettings::title);
	}

	void OnCommandLineChanged(const FText &InLabel)
	{
		SetupUErSettings::commandLine = InLabel.ToString();
	}

	FText GetCommandLineString() const
	{
		return FText::FromString(SetupUErSettings::commandLine);
	}

	void OnUIScaleChanged(const FText &InLabel)
	{
		SetupUErSettings::minResY = FCString::Atoi(*InLabel.ToString());
	}

	FText GetUIScaleString() const
	{
		return FText::FromString(FString::FromInt(SetupUErSettings::minResY));
	}

	FString GetLogoPath() const
	{
		if (logoTexture)
			return logoTexture->GetPathName();
		else
			return FString("");
	}

	void OnLogoPathChanged(const FAssetData& AssetData)
	{
		logoTexture = Cast<UTexture2D>(AssetData.GetAsset());
		if (logoTexture != NULL)
		{
			if (!((logoTexture->Resource->GetSizeX()==300) && (logoTexture->Resource->GetSizeY()==100)))
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("Use a 300x100 texture for best results!\r\nOther resolutions will be resized."));
			FString textureName = logoTexture->GetFullName();
			textureName.RemoveFromStart("Texture2D ");
			SetupUErSettings::logoName = FName(*textureName);
			FSlateApplication::Get().GetRenderer()->ReleaseDynamicResource(*logoBrush.Get());
			logoBrush.Reset();
			logoBrush = TSharedPtr<FSlateDynamicImageBrush>(new FSlateDynamicImageBrush(logoTexture, logoSize, logoTexture->GetFName()));
		}
		else
		{
			SetupUErSettings::logoName = cEmptyTexture;  // Never actually be null or the world will implode. Possibly.
			FSlateApplication::Get().GetRenderer()->ReleaseDynamicResource(*logoBrush.Get());
			logoBrush.Reset();
			logoTexture = LoadObject<UTexture2D>(NULL, *SetupUErSettings::logoName.ToString());
			logoBrush = TSharedPtr<FSlateDynamicImageBrush>(new FSlateDynamicImageBrush(logoTexture, logoSize, logoTexture->GetFName()));
		}
	}

	const FSlateBrush* GetLogoImage() const
	{
		return (logoBrush.IsValid()) ? logoBrush.Get() : FSetupUErEditorStyle::Get().GetBrush("SetupUErEditor.OpenPluginWindow");
	}

	TSharedPtr<FSlateDynamicImageBrush> GetLogoBrush()
	{
		return logoBrush;
	}

	ECheckBoxState GetLoadNextActive() const
	{
		return SetupUErSettings::isActive ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
	}

	void OnLoadNextChanged(ECheckBoxState NewState)
	{
		SetupUErSettings::isActive = (NewState == ECheckBoxState::Checked);
	}


	ECheckBoxState GetWonkyActive() const
	{
		return SetupUErSettings::allowWonkyKeys ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
	}

	void OnWonkyChanged(ECheckBoxState NewState)
	{
		SetupUErSettings::allowWonkyKeys = (NewState == ECheckBoxState::Checked);
	}

};
// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once

#include "SlateBasics.h"
#include "SetupUErEditorStyle.h"

class FSetupUErEditorCommands : public TCommands<FSetupUErEditorCommands>
{
public:

	FSetupUErEditorCommands()
		: TCommands<FSetupUErEditorCommands>(TEXT("SetupUErEditor"), NSLOCTEXT("Contexts", "SetupUErEditor", "SetupUErEditor Plugin"), NAME_None, FSetupUErEditorStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr< FUICommandInfo > OpenPluginWindow;
};
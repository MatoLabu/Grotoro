// SetupUEr - Basic Editor version of the settings file
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#pragma once

#include "SetupUErEditorPrivatePCH.h"

static const FName cEmptyTexture = "/Engine/EngineResources/WhiteSquareTexture.WhiteSquareTexture";

// plugin types
static const FString cGraphics = "Graphics";
static const FString cQuality = "Quality";
static const FString cKeyboard = "Keyboard";

class SetupUErSettings
{
public: 

	static FString title;
	static FString commandLine;
	static FName logoName;
	static bool isActive;
	static bool allowWonkyKeys;
	static TArray<FString> activePlugins;
	static int minResY;

	static void LoadConfig()
	{
		isActive = false;
		title = "U N T I T L E D";
		logoName = cEmptyTexture;
		minResY = 720;
		allowWonkyKeys = false;
		activePlugins.Add(cGraphics);
		FString configName = FPaths::GameConfigDir() + "SetupUEr.cfg";
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*(configName)))
		{
			TArray<FString> configLines;
			FString UTF16test;
			FFileHelper::LoadFileToString(UTF16test, *configName);
			UTF16test = UTF16test.Replace(TEXT("\r"), TEXT(""));
			UTF16test.ParseIntoArray(configLines, TEXT("\n"), false);
			UTF16test.Empty();
			if (configLines.Num() == 7)
			{
				activePlugins.Empty();
				isActive = (FCString::Atoi(*configLines[0]) == 1)?true:false;
				title = configLines[1];
				logoName = FName(*configLines[2]);
				commandLine = configLines[3];
				configLines[4].ParseIntoArray(activePlugins, TEXT(","));
				minResY = FCString::Atoi(*configLines[5]);
				allowWonkyKeys = (FCString::Atoi(*configLines[6]) == 1) ? true : false;
			}
		}
	}


	static void SaveConfig()
	{
		FString configName = FPaths::GameConfigDir() + "SetupUEr.cfg";
		FString outputString;
		outputString += FString::FromInt((int)isActive) + "\r\n";
		outputString += title + "\r\n";
		outputString += logoName.ToString()+"\r\n";
		outputString += commandLine+"\r\n";
		for (int i = 0; i < activePlugins.Num(); i++)
		{
			outputString += activePlugins[i];
			if (i<activePlugins.Num()-1)
				outputString += ",";
		}
		outputString += "\r\n";
		outputString += FString::FromInt(minResY)+"\r\n";
		outputString += FString::FromInt((int)allowWonkyKeys);

		FFileHelper::SaveStringToFile(outputString, *configName);
	}
};
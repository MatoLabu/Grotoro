// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.


#include "SetupUErEditorPrivatePCH.h"
#include "SetupUErSettingsEditor.h"

bool SetupUErSettings::isActive;
bool SetupUErSettings::allowWonkyKeys;
FString SetupUErSettings::title;
FString SetupUErSettings::commandLine;
FName SetupUErSettings::logoName;
TArray<FString> SetupUErSettings::activePlugins;
int SetupUErSettings::minResY;
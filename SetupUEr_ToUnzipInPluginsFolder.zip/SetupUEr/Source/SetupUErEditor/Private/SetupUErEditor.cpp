// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErEditorPrivatePCH.h"

#include "SlateBasics.h"
#include "SlateExtras.h"
#include "MainFrame.h"

#include "SetupUErEditorStyle.h"
#include "SetupUErEditorCommands.h"

#include "SetupUErSettingsEditor.h"
#include "SetupUErEditorWidget.h"

#include "LevelEditor.h"

static const FName SetupUErEditorTabName("SetupUErEditor");

#define LOCTEXT_NAMESPACE "FSetupUErEditorModule"

void FSetupUErEditorModule::StartupModule()
{
	FSetupUErEditorStyle::Initialize();
	FSetupUErEditorStyle::ReloadTextures();

	FSetupUErEditorCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FSetupUErEditorCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FSetupUErEditorModule::PluginButtonClicked),
		FCanExecuteAction());
		
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	{
		TSharedPtr<FExtender> MenuExtender = MakeShareable(new FExtender());
		MenuExtender->AddMenuExtension("WindowLayout", EExtensionHook::After, PluginCommands, FMenuExtensionDelegate::CreateRaw(this, &FSetupUErEditorModule::AddMenuExtension));

		LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(MenuExtender);
	}

	TSharedPtr<FExtender> ToolbarExtender = MakeShareable(new FExtender);
	ToolbarExtender->AddToolBarExtension("Settings", EExtensionHook::After, PluginCommands, FToolBarExtensionDelegate::CreateRaw(this, &FSetupUErEditorModule::AddToolbarExtension));

	LevelEditorModule.GetToolBarExtensibilityManager()->AddExtender(ToolbarExtender);
}

void FSetupUErEditorModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
	FSetupUErEditorStyle::Shutdown();

	FSetupUErEditorCommands::Unregister();

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(SetupUErEditorTabName);
}

void FSetupUErEditorModule::PluginButtonClicked()
{
	SetupUErSettings::LoadConfig();


	TSharedRef<SWindow> SetupUErWindow = SNew(SWindow)
		.Title(LOCTEXT("SetupUEr", "SetupUEr v1.1.1119 � NT Entertainment"))
		.ClientSize(FVector2D(346, 400))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		[
			SNew(SetupUErEditorWidget)
		];

	IMainFrameModule& MainFrameModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));

	if (MainFrameModule.GetParentWindow().IsValid())
	{
		FSlateApplication::Get().AddWindowAsNativeChild(SetupUErWindow, MainFrameModule.GetParentWindow().ToSharedRef());
	}
	else
	{
		FSlateApplication::Get().AddWindow(SetupUErWindow);
	}
}

void FSetupUErEditorModule::AddMenuExtension(FMenuBuilder& Builder)
{
	Builder.AddMenuEntry(FSetupUErEditorCommands::Get().OpenPluginWindow);
}

void FSetupUErEditorModule::AddToolbarExtension(FToolBarBuilder& Builder)
{
	Builder.AddToolBarButton(FSetupUErEditorCommands::Get().OpenPluginWindow);
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FSetupUErEditorModule, SetupUErEditor)
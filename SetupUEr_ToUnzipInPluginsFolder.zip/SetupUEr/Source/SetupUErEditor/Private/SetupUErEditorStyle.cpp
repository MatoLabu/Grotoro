// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErEditorPrivatePCH.h"
#include "SetupUErEditorStyle.h"
#include "SlateGameResources.h"
#include "IPluginManager.h"

TSharedPtr< FSlateStyleSet > FSetupUErEditorStyle::StyleInstance = NULL;

void FSetupUErEditorStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FSetupUErEditorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FSetupUErEditorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("SetupUErEditorStyle"));
	return StyleSetName;
}

const FVector2D Icon16x16(16.0f, 16.0f);
const FVector2D Icon20x20(20.0f, 20.0f);
const FVector2D Icon40x40(40.0f, 40.0f);

TSharedRef< FSlateStyleSet > FSetupUErEditorStyle::Create()
{
	TSharedRef< FSlateStyleSet > Style = MakeShareable(new FSlateStyleSet("SetupUErEditorStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("SetupUEr")->GetBaseDir() / TEXT("Resources"));

	Style->Set("SetupUErEditor.Background", FWindowStyle().SetBackgroundBrush(FSlateColorBrush(FLinearColor::Black)));
	Style->Set("SetupUErEditor.OpenPluginWindow", new FSlateImageBrush(Style->RootToContentDir(TEXT("ButtonIcon_40x"), TEXT(".png")), Icon40x40));
	Style->Set("SetupUErEditor.ArrowUp", new FSlateImageBrush(Style->RootToContentDir(TEXT("ArrowUp_16x"), TEXT(".png")), Icon16x16));
	Style->Set("SetupUErEditor.ArrowDown", new FSlateImageBrush(Style->RootToContentDir(TEXT("ArrowDown_16x"), TEXT(".png")), Icon16x16));

	return Style;
}

void FSetupUErEditorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FSetupUErEditorStyle::Get()
{
	return *StyleInstance;
}

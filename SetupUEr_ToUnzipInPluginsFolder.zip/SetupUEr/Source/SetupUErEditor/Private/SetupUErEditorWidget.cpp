// SetupUEr
// Copyright 2016 Turfster / NT Entertainment
// All Rights Reserved.

#include "SetupUErEditorPrivatePCH.h"
#include "SetupUErEditorWidget.h"

#include "UnrealEd.h"

#include "SlateBasics.h"
#include "SlateExtras.h"

#include "SetupUErSettingsEditor.h"

#include "PropertyCustomizationHelpers.h"


#define LOCTEXT_NAMESPACE "SetupUErEditorWidget"
void SetupUErEditorWidget::Construct(const FArguments& InArgs)
{
	logoTexture = LoadObject<UTexture2D>(NULL, *SetupUErSettings::logoName.ToString());
	logoBrush = TSharedPtr<FSlateDynamicImageBrush>(new FSlateDynamicImageBrush(logoTexture, logoSize, logoTexture->GetFName()));

	pluginsList.Empty();
	// add all the plugin types
	pluginsList.Add(MakeShareable(new PluginListEntry(SetupUErSettings::activePlugins.Contains(cGraphics) ? SetupUErSettings::activePlugins.IndexOfByKey(cGraphics) : cDisabledPlugin, cGraphics, SetupUErSettings::activePlugins.Contains(cGraphics) ? true : false)));
	pluginsList.Add(MakeShareable(new PluginListEntry(SetupUErSettings::activePlugins.Contains(cQuality) ? SetupUErSettings::activePlugins.IndexOfByKey(cQuality) : cDisabledPlugin, cQuality, SetupUErSettings::activePlugins.Contains(cQuality) ? true : false)));
	pluginsList.Add(MakeShareable(new PluginListEntry(SetupUErSettings::activePlugins.Contains(cKeyboard) ? SetupUErSettings::activePlugins.IndexOfByKey(cKeyboard) : cDisabledPlugin, cKeyboard, SetupUErSettings::activePlugins.Contains(cKeyboard) ? true : false)));
	DoReorder(false);


	ChildSlot
	[
		SNew(SVerticalBox)
		+SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("gamename","Game name: "))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SEditableTextBox)
					.MinDesiredWidth(250)
					.OnTextChanged(this, &SetupUErEditorWidget::OnGameNameChanged)
					.Text(this, &SetupUErEditorWidget::GetGameNameString)
					.ToolTipText(LOCTEXT("NameTooltip", "Game name to use as header for the SetupUEr window"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Top)
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(100)
			.WidthOverride(300)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(SImage)
				.Image(this, &SetupUErEditorWidget::GetLogoImage)
				.ToolTipText(LOCTEXT("preview", "Preview image"))
			]
		]
		+SVerticalBox::Slot()
		.Padding(3.0f, 1.0f)
		.AutoHeight()
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("gamelogo","Game logo: "))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SObjectPropertyEntryBox)
					.ObjectPath(this, &SetupUErEditorWidget::GetLogoPath)
					.OnObjectChanged(this, &SetupUErEditorWidget::OnLogoPathChanged)
					.AllowedClass(UTexture2D::StaticClass())
					.ToolTipText(LOCTEXT("LogoTooltip", "Texture2D you want to use as a logo"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("defaultCommandline", "Default commandline: "))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SEditableTextBox)
					.MinDesiredWidth(250)
					.OnTextChanged(this, &SetupUErEditorWidget::OnCommandLineChanged)
					.Text(this, &SetupUErEditorWidget::GetCommandLineString)
					.ToolTipText(LOCTEXT("Commandline", "Any options you want to add as default command line options"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("defaultUIRes", "UI base Y resolution: "))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SEditableTextBox)
					.MinDesiredWidth(250)
					.OnTextChanged(this, &SetupUErEditorWidget::OnUIScaleChanged)
					.Text(this, &SetupUErEditorWidget::GetUIScaleString)
					.ToolTipText(LOCTEXT("UIResTooltip", "What is the height your UMG/Slate UI was authored at?"))
				]
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("LoadNext", "Show setup at game start?"))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SCheckBox)
					.IsChecked(this, &SetupUErEditorWidget::GetLoadNextActive)
					.OnCheckStateChanged(this, &SetupUErEditorWidget::OnLoadNextChanged)
					.ToolTipText(LOCTEXT("LoadNextTooltip", "Show the setup window the next time the game starts?"))
				]
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("allowWonky", "Allow hard to detect keys?"))
				]
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SCheckBox)
					.IsChecked(this, &SetupUErEditorWidget::GetWonkyActive)
					.OnCheckStateChanged(this, &SetupUErEditorWidget::OnWonkyChanged)
					.ToolTipText(LOCTEXT("allowWonkyTooltip", "When ticked, will allow your user to try to use non default qwerty layout keys that have no real Unreal Engine key constants defined for them.\r\nThey work for one session, but can't stick because I can't reverse-assign them. (Think �, �, �, <, etc)"))
				]
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(120.f)
			[
				SAssignNew(pluginListWidget, SListView<TSharedPtr<PluginListEntry>>)
				.ItemHeight(30)
				.ListItemsSource(&pluginsList)
				.SelectionMode(ESelectionMode::None)
				.OnGenerateRow(this, &SetupUErEditorWidget::MakeListViewWidget)
				.HeaderRow(
					SNew(SHeaderRow)
					+ SHeaderRow::Column("order").DefaultLabel(LOCTEXT("header_order", "Ordering")).HAlignCell(HAlign_Center).HAlignHeader(HAlign_Left).FixedWidth(80)
					+ SHeaderRow::Column("type").DefaultLabel(LOCTEXT("header_type","Setup type")).HAlignCell(HAlign_Left).HAlignHeader(HAlign_Left).VAlignCell(VAlign_Center)
					+ SHeaderRow::Column("active").DefaultLabel(LOCTEXT("header_active", "Include")).HAlignCell(HAlign_Left).HAlignHeader(HAlign_Left).FixedWidth(70)
				)
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(3.0f, 1.0f)
		[
			SNew(SBox)
			.HeightOverride(24)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				[
					SNew(SButton)
					.OnClicked(this, &SetupUErEditorWidget::DoSaveSettings)
					.IsEnabled(true)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Text(LOCTEXT("Save", "Save"))
					
				]
			]
		]
	];
}

TSharedRef<ITableRow> SetupUErEditorWidget::MakeListViewWidget(TSharedPtr<PluginListEntry> Item, const TSharedRef<STableViewBase> &OwnerTable)
{
	DoUpdateDelegate reorderDelegate;
	DoMoveDelegate shiftDelegate;
	reorderDelegate.BindSP(this, &SetupUErEditorWidget::DoReorder);
	shiftDelegate.BindSP(this, &SetupUErEditorWidget::DoMoveUpDown);

	class PluginComboWidget : public SMultiColumnTableRow<TSharedPtr<PluginListEntry>>
	{
		public:
		SLATE_BEGIN_ARGS(PluginComboWidget){}
		SLATE_END_ARGS()

		TSharedPtr<PluginListEntry> Item;
		DoUpdateDelegate myDelegate;
		DoMoveDelegate myShiftDelegate;

		void Construct(const FArguments &InArgs, const TSharedRef<STableViewBase> &InOwnerTable, TSharedPtr<PluginListEntry> InItem, DoUpdateDelegate inDelegate, DoMoveDelegate inShiftDelegate)
		{
			Item = InItem;
			myDelegate = inDelegate;
			myShiftDelegate = inShiftDelegate;
			SMultiColumnTableRow<TSharedPtr<PluginListEntry>>::Construct(FSuperRowType::FArguments(), InOwnerTable);
		}

		ECheckBoxState GetActive() const
		{
			if (Item->isActive) return ECheckBoxState::Checked; else return ECheckBoxState::Unchecked;
		}

		void SetActive(ECheckBoxState inState)
		{
			Item->isActive = (inState == ECheckBoxState::Checked);
			myDelegate.Execute(true);
		}

		FText GetCurrentOrder() const
		{
			return FText::FromString(FString::FromInt(Item->order));
		}

		void OnOrderChanged(const FText &InLabel)
		{
			Item->order = FCString::Atoi(*InLabel.ToString());
			myDelegate.Execute(true);
		}

		FText GetPluginType() const
		{
			switch (Item->myType)
			{
			case 0:
				return FText::FromString(cQuality);
				break;
			case 1:
				return FText::FromString(cKeyboard);
				break;
			case 2:
				return FText::FromString(cGraphics);
				break;
			// add your plugin types here
			}
			return FText::FromString("Undefined");
		}

		bool CanUp() const
		{
			return (Item->order > 0 && Item->order < 250);
		}

		bool CanDown() const
		{
			return (Item->order < 250 && !Item->lastActive && !Item->lastItem);
		}

		FReply MoveUp()
		{
			myShiftDelegate.Execute(Item->order, true);
			return FReply::Handled();
		}

		FReply MoveDown()
		{
			myShiftDelegate.Execute(Item->order, false);
			return FReply::Handled();
		}

		TSharedRef<SWidget> GenerateWidgetForColumn(const FName &ColumnName)
		{

			if (ColumnName == "order")
			{
				return 
					SNew(SBox)
					.HAlign(HAlign_Center)
					[
					SNew(SHorizontalBox)
					+SHorizontalBox::Slot()
					.AutoWidth()
					.Padding(3.f, 0.f)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					[
						SNew(SBox)
						.WidthOverride(16)
						.HeightOverride(16)
						[
							SNew(SButton)
							.ButtonStyle(FCoreStyle::Get(), "NoBorder")
							.IsEnabled(this, &PluginComboWidget::CanUp)
							.OnClicked(this, &PluginComboWidget::MoveUp)
							.ForegroundColor(FSlateColor::UseForeground())
							[
								SNew(SImage)
								.Image(FSetupUErEditorStyle::Get().GetBrush("SetupUErEditor.ArrowUp"))
							]
						]
					]
					+SHorizontalBox::Slot()
					.AutoWidth()
					.Padding(3.f, 0.f)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					[
						SNew(SBox)
						.WidthOverride(16)
						.HeightOverride(16)
						[
							SNew(SButton)
							.ButtonStyle(FCoreStyle::Get(), "NoBorder")
							.IsEnabled(this, &PluginComboWidget::CanDown)
							.OnClicked(this, &PluginComboWidget::MoveDown)
							.ForegroundColor(FSlateColor::UseForeground())
							[	
								SNew(SImage)
								.Image(FSetupUErEditorStyle::Get().GetBrush("SetupUErEditor.ArrowDown"))
							]
						]
					]
				];
			}
			if (ColumnName == "active")
			{
				return
					SNew(SCheckBox)
					.IsChecked(this, &PluginComboWidget::GetActive)
					.OnCheckStateChanged(this, &PluginComboWidget::SetActive);
			}
			if (ColumnName == "type")
			{
				return SNew(STextBlock)
					.Text(this, &PluginComboWidget::GetPluginType);
			}
			return SNew(STextBlock)
				.Text(FText::FromString("What"));
		}

	};
	return SNew(PluginComboWidget, OwnerTable, Item, reorderDelegate, shiftDelegate);
}

#undef LOCTEXT_NAMESPACE

// Copyright (c), Firelight Technologies Pty, Ltd. 2012-2017.
#pragma once

#include "CoreMinimal.h"
#include "Object.h"
#include "Components/SceneComponent.h"
#include "Runtime/Launch/Resources/Version.h"
#if WITH_EDITOR
#include "UnrealEd.h"
#endif
DECLARE_LOG_CATEGORY_EXTERN(LogFMOD, Log, All);

